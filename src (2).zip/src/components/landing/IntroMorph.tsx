"use client";

import React, { useLayoutEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useReducedMotion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import HeroStage from "@/components/landing/HeroStage";

gsap.registerPlugin(ScrollTrigger);

export default function IntroMorph() {
  const prefersReduced = useReducedMotion();

  const pinRef = useRef<HTMLElement | null>(null);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const overlayImgRef = useRef<HTMLDivElement | null>(null);
  const overlayCopyRef = useRef<HTMLDivElement | null>(null);
  const heroRevealRef = useRef<HTMLDivElement | null>(null);
  const navDarkRef = useRef<HTMLDivElement | null>(null);
  const navLightRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (prefersReduced) {
      if (overlayRef.current) overlayRef.current.style.opacity = "0";
      if (navDarkRef.current) navDarkRef.current.style.opacity = "0";
      if (navLightRef.current) navLightRef.current.style.opacity = "1";
      if (heroRevealRef.current) heroRevealRef.current.style.opacity = "1";
      return;
    }

    if (!pinRef.current || !overlayRef.current || !overlayImgRef.current || !heroRevealRef.current) return;

    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(heroRevealRef.current, { 
        opacity: 0, 
        y: 20,
        scale: 0.99
      });
      gsap.set(overlayRef.current, { opacity: 1 });
      gsap.set(overlayImgRef.current, { scale: 1 });
      gsap.set(overlayCopyRef.current, { opacity: 1, y: 0 });
      gsap.set(navDarkRef.current, { opacity: 1 });
      gsap.set(navLightRef.current, { opacity: 0 });

      // FAST scroll-driven timeline - shorter distance, snappier scrub
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: pinRef.current!,
          start: "top top",
          end: "+=80%", // Much shorter - faster reveal
          scrub: 0.3, // Snappier response
          pin: true,
          pinReparent: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Quick zoom on cover
      tl.to(
        overlayImgRef.current!,
        { 
          scale: 1.08, 
          duration: 1, 
          ease: "power1.out" 
        },
        0
      );

      // Fast fade copy
      tl.to(
        overlayCopyRef.current!,
        { 
          opacity: 0, 
          y: -15,
          duration: 0.35, 
          ease: "power2.out" 
        },
        0
      );

      // Quick dissolve overlay
      tl.to(
        overlayRef.current!,
        { 
          opacity: 0, 
          duration: 0.5, 
          ease: "power2.out" 
        },
        0.1
      );

      // Nav swap - fast
      tl.to(
        navDarkRef.current!,
        { 
          opacity: 0, 
          duration: 0.25, 
          ease: "power1.out" 
        },
        0.15
      );
      tl.to(
        navLightRef.current!,
        { 
          opacity: 1, 
          duration: 0.25, 
          ease: "power1.out" 
        },
        0.25
      );

      // Hero reveal - quick emergence
      tl.to(
        heroRevealRef.current!,
        { 
          opacity: 1, 
          y: 0, 
          scale: 1,
          duration: 0.5, 
          ease: "power2.out" 
        },
        0.05
      );
    }, pinRef);

    return () => ctx.revert();
  }, [prefersReduced]);

  const refreshST = () => {
    if (prefersReduced) return;
    requestAnimationFrame(() => ScrollTrigger.refresh());
  };

  return (
    <section
      ref={(n) => { pinRef.current = n; }}
      className="introPin relative overflow-hidden bg-[#0a0a0a]"
      aria-label="Intro reveal"
    >
      {/* HERO UNDERLAYER */}
      <div ref={heroRevealRef} className="relative will-change-transform">
        <HeroStage />
      </div>

      {/* INTRO OVERLAY */}
      <div
        ref={(n) => { overlayRef.current = n; }}
        className="introOverlay absolute inset-0 will-change-opacity"
      >
        {/* Background Image */}
        <div
          ref={(n) => { overlayImgRef.current = n; }}
          className="absolute inset-0 will-change-transform"
        >
          <Image
            src="/Pictures/yard.jpg"
            alt="The Yard"
            fill
            priority
            sizes="100vw"
            className="object-cover"
            onLoadingComplete={refreshST}
          />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_30%_20%,rgba(255,255,255,0.06),transparent)]" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/15 via-black/35 to-black/75" />
          <div className="absolute inset-0 vignette-dark" />
          <div className="absolute inset-0 grain opacity-[0.12]" />
        </div>

        {/* Dark Nav (white text) */}
        <div
          ref={navDarkRef}
          className="fixed left-0 right-0 top-0 z-30"
          aria-hidden={prefersReduced ? true : false}
        >
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6 sm:py-5 md:px-10 md:py-6">
            <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
              <span className="text-xl sm:text-2xl font-black text-white transition-transform duration-200 group-hover:scale-110">☥</span>
              <span className="text-xs sm:text-sm font-bold tracking-[0.15em] sm:tracking-[0.18em] text-white/85">THE YARD</span>
            </Link>

            {/* Mobile menu button */}
            <button className="flex md:hidden items-center justify-center w-10 h-10 rounded-full bg-white/10 text-white">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            <div className="hidden items-center gap-6 lg:gap-8 md:flex">
              <a href="#houses" className="nav-link-light">Houses</a>
              <a href="#feed" className="nav-link-light">Feed</a>
              <a href="#pass" className="nav-link-light">Yard Pass</a>
              <Link href="/profile" className="nav-btn-light">Sign in</Link>
            </div>
          </nav>
        </div>

        {/* Light Nav (dark text) */}
        <div
          ref={navLightRef}
          className="fixed left-0 right-0 top-0 z-30"
        >
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6 sm:py-5 md:px-10 md:py-6">
            <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
              <span className="text-xl sm:text-2xl font-black text-black transition-transform duration-200 group-hover:scale-110">☥</span>
              <span className="text-xs sm:text-sm font-bold tracking-[0.15em] sm:tracking-[0.18em] text-black/75">THE YARD</span>
            </Link>

            {/* Mobile menu button */}
            <button className="flex md:hidden items-center justify-center w-10 h-10 rounded-full bg-black/5 text-black">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            <div className="hidden items-center gap-6 lg:gap-8 md:flex">
              <a href="#houses" className="nav-link">Houses</a>
              <a href="#feed" className="nav-link">Feed</a>
              <a href="#pass" className="nav-link">Yard Pass</a>
              <Link href="/profile" className="nav-btn">Sign in</Link>
            </div>
          </nav>
        </div>

        {/* Hero Copy - Mobile Optimized */}
        <div
          ref={overlayCopyRef}
          className="relative z-10 mx-auto flex h-full max-w-6xl items-end px-4 pb-10 sm:px-6 sm:pb-14 md:px-10 md:pb-20"
        >
          <div className="max-w-2xl space-y-4 sm:space-y-5 md:space-y-6">
            {/* Tags - smaller on mobile */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <span className="chip-dark text-[10px] sm:text-xs py-1.5 px-2.5 sm:py-2 sm:px-3">Enter the Yard</span>
              <span className="chip-dark text-[10px] sm:text-xs py-1.5 px-2.5 sm:py-2 sm:px-3">Members-only</span>
            </div>

            {/* Headline - responsive sizing */}
            <h1 className="title-hero text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white leading-[0.95]">
              Enter the Yard.
            </h1>

            {/* Subline */}
            <p className="max-w-xl text-sm sm:text-base md:text-lg font-medium text-white/70 leading-relaxed">
              Not a public page. Not a regular sign-up.
              <span className="font-bold text-white"> Your ID is your entry.</span>
            </p>

            {/* CTAs - stack on mobile */}
            <div className="flex flex-col sm:flex-row gap-3 pt-1">
              <a href="#pass" className="btn-gold text-sm sm:text-base justify-center">
                Generate my Yard Pass
                <span className="text-base sm:text-lg">☥</span>
              </a>
              <a href="#houses" className="btn-ghost-light text-sm sm:text-base justify-center">
                Choose a house
              </a>
            </div>

            {/* Scroll hint - hide on small mobile */}
            <p className="hidden sm:block pt-2 text-[10px] sm:text-xs font-bold tracking-[0.18em] text-white/35 uppercase">
              Scroll to reveal
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
