"use client";

import React, { useLayoutEffect, useRef } from "react";
import { useReducedMotion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import PassGenerator from "@/components/landing/pass/PassGenerator";
import { Caption } from "@/components/landing/atoms";

gsap.registerPlugin(ScrollTrigger);

export default function YardPassSection() {
  const prefersReduced = useReducedMotion();
  const sectionRef = useRef<HTMLElement | null>(null);
  const generatorRef = useRef<HTMLDivElement | null>(null);
  const sideCardsRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (prefersReduced) return;

    const ctx = gsap.context(() => {
      // Generator card reveal - faster
      gsap.from(generatorRef.current, {
        scrollTrigger: {
          trigger: generatorRef.current,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
        y: 35,
        opacity: 0,
        duration: 0.6,
        ease: "power2.out",
      });

      // Side cards stagger - faster
      gsap.from(".side-card", {
        scrollTrigger: {
          trigger: sideCardsRef.current,
          start: "top 90%",
          toggleActions: "play none none reverse",
        },
        y: 30,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        ease: "power2.out",
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [prefersReduced]);

  return (
    <section
      ref={(n) => { sectionRef.current = n; }}
      id="pass"
      className="grid gap-4 sm:gap-5 md:gap-6 lg:grid-cols-2"
    >
      {/* Pass Generator */}
      <div
        ref={generatorRef}
        className="card-ink relative overflow-hidden p-5 sm:p-6 md:p-8 lg:p-10 border-glow"
      >
        {/* Background effects */}
        <div className="absolute inset-0 opacity-50">
          <div className="absolute inset-0 vignette-dark" />
          <div className="absolute inset-0 grain" />
        </div>

        {/* Decorative ankh */}
        <div className="absolute -right-10 sm:-right-12 md:-right-16 -top-10 sm:-top-12 md:-top-16 text-[140px] sm:text-[170px] md:text-[200px] font-black text-[rgb(var(--yard-gold))]/[0.03] leading-none pointer-events-none">
          ☥
        </div>

        <div className="relative space-y-4 sm:space-y-5 md:space-y-6">
          <div>
            <Caption>YARD PASS</Caption>
            <h2 className="mt-3 sm:mt-4 title-section text-2xl sm:text-3xl md:text-4xl text-[rgb(var(--yard-gold))]">
              Generate your ID.
            </h2>
            <p className="mt-2 sm:mt-3 body-text-light text-sm sm:text-base max-w-md">
              Your pass is your entry. Pick your house, upload a photo, and export a clean card.
            </p>
          </div>

          <PassGenerator />
        </div>
      </div>

      {/* Side Cards */}
      <div ref={sideCardsRef} className="grid gap-4 sm:gap-5 content-start">
        {/* Why Card */}
        <div className="side-card card-paper p-5 sm:p-6 md:p-8 lg:p-10 ankh-pattern">
          <div className="relative">
            <Caption>WHY</Caption>
            <h3 className="mt-3 sm:mt-4 title-section text-xl sm:text-2xl">Real updates. No noise.</h3>
            <p className="mt-2 sm:mt-3 body-text text-sm sm:text-base">
              Once you have a pass, you get house-specific drops, show dates, and private links.
            </p>
            
            <div className="mt-4 sm:mt-6 flex flex-wrap gap-1.5 sm:gap-2">
              <span className="chip text-[10px] sm:text-xs">Show updates</span>
              <span className="chip text-[10px] sm:text-xs">News</span>
              <span className="chip text-[10px] sm:text-xs">Early links</span>
              <span className="chip text-[10px] sm:text-xs">House perks</span>
            </div>
          </div>
        </div>

        {/* Rules Card */}
        <div className="side-card card-frame p-5 sm:p-6 md:p-8 lg:p-10">
          <div className="absolute inset-0 micro-grid opacity-[0.06]" />
          <div className="absolute inset-0 grain opacity-[0.06]" />
          
          <div className="relative">
            <Caption>RULES</Caption>
            <h3 className="mt-3 sm:mt-4 title-section text-xl sm:text-2xl">Keep it simple.</h3>
            
            <ul className="mt-4 sm:mt-5 space-y-2.5 sm:space-y-3">
              <li className="flex items-start gap-2.5 sm:gap-3">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-black/25 shrink-0" />
                <span className="body-text text-sm sm:text-base">No spam — one pass per person.</span>
              </li>
              <li className="flex items-start gap-2.5 sm:gap-3">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-black/25 shrink-0" />
                <span className="body-text text-sm sm:text-base">House is assigned by your pick.</span>
              </li>
              <li className="flex items-start gap-2.5 sm:gap-3">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-black/25 shrink-0" />
                <span className="body-text text-sm sm:text-base">We only use your info for Yard updates.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
