"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";

type Gender = "male" | "female" | "";

export type PassCard = {
  id: string;
  name: string;
  email: string;
  phone: string;
  houseLabel: "Descendant" | "Angel";
  createdAt: string;
  photoDataUrl?: string;
};

export default function PassGenerator() {
  const prefersReduced = useReducedMotion();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [gender, setGender] = useState<Gender>("");
  const [photoDataUrl, setPhotoDataUrl] = useState<string | undefined>(undefined);

  const [card, setCard] = useState<PassCard | null>(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string>("");

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawSeqRef = useRef(0);

  // Load previously saved card (optional)
  useEffect(() => {
    try {
      const raw = localStorage.getItem("yard_pass_card_v1");
      if (!raw) return;
      const parsed = JSON.parse(raw) as PassCard;
      setCard(parsed);
    } catch {}
  }, []);

  // Always show *something* in the preview canvas (even before generating)
  const renderCard = useMemo<PassCard>(() => {
    if (card) return card;

    const houseLabel: PassCard["houseLabel"] =
      gender === "female" ? "Angel" : "Descendant";

    return {
      id: "YARD-XX-XXXXXXXX",
      name: "YOUR NAME",
      email: "you@email.com",
      phone: "+234...",
      houseLabel,
      createdAt: new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      photoDataUrl,
    };
  }, [card, gender, photoDataUrl]);

  // Draw (and safely handle async image/font loading + stale draws)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const seq = ++drawSeqRef.current;
    const isStale = () => seq !== drawSeqRef.current;

    void drawPass(canvas, renderCard, isStale);

    // Keep it crisp on resize
    const onResize = () => {
      const seq2 = ++drawSeqRef.current;
      const isStale2 = () => seq2 !== drawSeqRef.current;
      void drawPass(canvas, renderCard, isStale2);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [renderCard]);

  // Auto-save generated card
  useEffect(() => {
    if (!card) return;
    try {
      localStorage.setItem("yard_pass_card_v1", JSON.stringify(card));
    } catch {}
  }, [card]);

  const onPickPhoto = async (file?: File | null) => {
    if (!file) return setPhotoDataUrl(undefined);
    const reader = new FileReader();
    reader.onload = () => setPhotoDataUrl(String(reader.result || ""));
    reader.readAsDataURL(file);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");

    const n = name.trim();
    const em = email.trim();
    const ph = phone.trim();

    if (!n || !em || !ph || !gender) {
      setErr("Please fill name, email, phone, and select gender.");
      return;
    }

    const id = `YARD-${new Date().getFullYear().toString().slice(-2)}-${Math.random()
      .toString(36)
      .slice(2, 10)
      .toUpperCase()}`;

    const houseLabel: PassCard["houseLabel"] =
      gender === "male" ? "Descendant" : "Angel";

    const createdAt = new Date().toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

    setCard({
      id,
      name: n,
      email: em,
      phone: ph,
      houseLabel,
      createdAt,
      photoDataUrl,
    });
  };

  const downloadPNG = async () => {
    if (!canvasRef.current) return;
    setSaving(true);
    try {
      const canvas = canvasRef.current;

      // ensure latest draw finished (best-effort)
      await new Promise((r) => requestAnimationFrame(() => r(null)));

      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob(resolve, "image/png")
      );
      if (!blob) return;

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = (card?.id || "yard-pass") + ".png";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setSaving(false);
    }
  };

  const saveToBrowser = () => {
    if (!card) return;
    try {
      localStorage.setItem("yard_pass_card_v1", JSON.stringify(card));
      setErr("");
    } catch {
      setErr("Could not save in this browser.");
    }
  };

  return (
    <div className="grid gap-4 sm:gap-5 md:gap-6 lg:grid-cols-2">
      <motion.form
        onSubmit={submit}
        className="rounded-xl sm:rounded-2xl border border-white/10 bg-black/25 p-4 sm:p-5 md:p-6 space-y-4 sm:space-y-5"
        initial={prefersReduced ? undefined : { opacity: 0, y: 15 }}
        animate={prefersReduced ? undefined : { opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <Field label="Full name">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="field text-sm sm:text-base"
            placeholder="Your name"
            required
          />
        </Field>

        <Field label="Email">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="field text-sm sm:text-base"
            placeholder="you@email.com"
            type="email"
            required
          />
        </Field>

        <Field label="Phone number">
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="field text-sm sm:text-base"
            placeholder="+234..."
            required
          />
        </Field>

        <Field label="Gender">
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <button
              type="button"
              onClick={() => setGender("male")}
              className={`gender-pill ${gender === "male" ? "gender-pill-active" : ""}`}
            >
              Male → Descendant
            </button>
            <button
              type="button"
              onClick={() => setGender("female")}
              className={`gender-pill ${gender === "female" ? "gender-pill-active" : ""}`}
            >
              Female → Angel
            </button>
          </div>
        </Field>

        <Field label="Upload photo">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => onPickPhoto(e.target.files?.[0])}
            className="file-input"
          />
          <p className="mt-1.5 sm:mt-2 text-[10px] sm:text-xs font-medium text-white/45">
            Tip: use a portrait photo.
          </p>
        </Field>

        {err ? (
          <p className="text-[11px] sm:text-xs font-semibold text-red-200/80">{err}</p>
        ) : null}

        <motion.button
          type="submit"
          className="w-full btn-gold text-sm sm:text-base"
          whileTap={prefersReduced ? undefined : { scale: 0.99 }}
        >
          Generate my card ☥
        </motion.button>
      </motion.form>

      <motion.div
        className="rounded-xl sm:rounded-2xl border border-white/10 bg-black/25 p-4 sm:p-5 md:p-6 space-y-4 sm:space-y-5"
        initial={prefersReduced ? undefined : { opacity: 0, y: 15 }}
        animate={prefersReduced ? undefined : { opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1], delay: 0.08 }}
      >
        <p className="label-light text-[10px] sm:text-xs">Your generated card</p>

        <div className="overflow-hidden rounded-xl sm:rounded-2xl border border-white/10 bg-black/35">
          <canvas ref={canvasRef} className="block h-auto w-full" />
        </div>

        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
          <motion.button
            type="button"
            onClick={downloadPNG}
            disabled={!card || saving}
            className="btn-gold text-sm sm:text-base disabled:opacity-40 disabled:cursor-not-allowed justify-center"
            whileTap={prefersReduced || !card ? undefined : { scale: 0.99 }}
          >
            {saving ? "Preparing..." : "Download PNG"}
          </motion.button>

          <motion.button
            type="button"
            onClick={saveToBrowser}
            disabled={!card}
            className="btn-ghost-light text-sm sm:text-base disabled:opacity-40 disabled:cursor-not-allowed justify-center"
            whileTap={prefersReduced || !card ? undefined : { scale: 0.99 }}
          >
            Save to browser
          </motion.button>
        </div>

        <p className="text-[10px] sm:text-xs font-medium text-white/45">
          Male → <span className="font-bold text-white/65">Descendant</span> • Female →{" "}
          <span className="font-bold text-white/65">Angel</span>
        </p>

        <style jsx>{`
          .gender-pill {
            border-radius: 10px;
            padding: 10px 12px;
            font-weight: 700;
            font-size: 11px;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.7);
            transition: all 150ms cubic-bezier(0.4, 0, 0.2, 1);
          }
          @media (min-width: 640px) {
            .gender-pill {
              border-radius: 12px;
              padding: 12px 14px;
              font-size: 12px;
            }
          }
          .gender-pill:hover {
            background: rgba(255, 255, 255, 0.06);
            border-color: rgba(255, 255, 255, 0.12);
          }
          .gender-pill-active {
            background: rgba(255, 210, 0, 0.1);
            border-color: rgba(255, 210, 0, 0.25);
            color: rgba(255, 255, 255, 0.92);
          }
          .file-input {
            width: 100%;
            border-radius: 10px;
            padding: 8px 10px;
            font-weight: 600;
            font-size: 12px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.7);
          }
          @media (min-width: 640px) {
            .file-input {
              border-radius: 12px;
              padding: 10px 12px;
              font-size: 13px;
            }
          }
          .file-input::-webkit-file-upload-button {
            padding: 5px 10px;
            margin-right: 10px;
            border-radius: 6px;
            border: none;
            background: rgba(255, 255, 255, 0.08);
            color: rgba(255, 255, 255, 0.75);
            font-weight: 600;
            font-size: 11px;
            cursor: pointer;
          }
        `}</style>
      </motion.div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="label-light text-[10px] sm:text-xs mb-1.5 sm:mb-2">{label}</p>
      {children}
    </div>
  );
}

async function drawPass(
  canvas: HTMLCanvasElement,
  card: PassCard,
  isStale?: () => boolean
) {
  // wait for fonts so text metrics are stable
  try {
    const fonts = (document as any).fonts;
    if (fonts?.ready) await fonts.ready;
  } catch {}

  if (isStale?.()) return;

  const W = 1080;
  const H = 1350;
  const dpr = Math.max(1, window.devicePixelRatio || 1);

  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  canvas.style.aspectRatio = `${W}/${H}`;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  // Background
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#0a0c10");
  bg.addColorStop(0.5, "#0d1015");
  bg.addColorStop(1, "#080a0d");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const glow = ctx.createRadialGradient(W * 0.75, H * 0.15, 0, W * 0.75, H * 0.15, 500);
  glow.addColorStop(0, "rgba(255,210,0,0.18)");
  glow.addColorStop(0.5, "rgba(255,210,0,0.06)");
  glow.addColorStop(1, "rgba(255,210,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  ctx.globalAlpha = 0.05;
  ctx.fillStyle = "rgba(255,210,0,1)";
  ctx.font = "900 400px system-ui";
  ctx.fillText("☥", -80, 500);
  ctx.globalAlpha = 1;

  // Main glass card
  roundedRect(ctx, 60, 70, W - 120, H - 140, 40);
  ctx.fillStyle = "rgba(255,255,255,0.035)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // Header
  ctx.fillStyle = "rgba(255,255,255,0.88)";
  ctx.font = "800 24px system-ui";
  ctx.fillText("THE YARD", 110, 150);
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.font = "600 13px system-ui";
  ctx.fillText("YARD PASS • MEMBERS ONLY", 110, 180);

  const chipText = card.houseLabel.toUpperCase();
  const chipW = Math.max(240, ctx.measureText(chipText).width + 70);
  roundedRect(ctx, W - 100 - chipW, 125, chipW, 48, 24);
  ctx.fillStyle = "rgba(255,210,0,0.1)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,210,0,0.2)";
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,0.88)";
  ctx.font = "700 12px system-ui";
  ctx.fillText(chipText, W - 100 - chipW + 28, 155);

  // Photo
  const px = 110,
    py = 230,
    pw = W - 220,
    ph = 680;
  roundedRect(ctx, px, py, pw, ph, 36);
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.stroke();

  if (card.photoDataUrl) {
    try {
      const img = await loadImage(card.photoDataUrl);
      if (isStale?.()) return;

      const scale = Math.max(pw / img.width, ph / img.height);
      const iw = img.width * scale;
      const ih = img.height * scale;
      const ix = px + (pw - iw) / 2;
      const iy = py + (ph - ih) / 2;

      ctx.save();
      roundedRect(ctx, px, py, pw, ph, 36);
      ctx.clip();
      ctx.drawImage(img, ix, iy, iw, ih);
      ctx.restore();

      const glaze = ctx.createLinearGradient(0, py, 0, py + ph);
      glaze.addColorStop(0, "rgba(0,0,0,0.08)");
      glaze.addColorStop(0.6, "rgba(0,0,0,0)");
      glaze.addColorStop(1, "rgba(0,0,0,0.35)");
      ctx.fillStyle = glaze;
      roundedRect(ctx, px, py, pw, ph, 36);
      ctx.fill();
    } catch {
      ctx.fillStyle = "rgba(255,255,255,0.1)";
      ctx.font = "600 18px system-ui";
      ctx.fillText("Photo could not be loaded.", px + 35, py + 60);
    }
  } else {
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    ctx.font = "600 18px system-ui";
    ctx.fillText("Upload a photo for the full look.", px + 35, py + 60);
  }

  // Name + details
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.font = "900 50px system-ui";
  wrapText(ctx, card.name.toUpperCase(), 110, 1000, W - 220, 56);

  ctx.fillStyle = "rgba(255,255,255,0.6)";
  ctx.font = "600 18px system-ui";
  ctx.fillText(card.email, 110, 1095);
  ctx.fillText(card.phone, 110, 1125);

  // Footer strip
  roundedRect(ctx, 110, 1165, W - 220, 80, 24);
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,210,0,0.18)";
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.7)";
  ctx.font = "700 13px ui-monospace";
  ctx.fillText(`ID: ${card.id}`, 140, 1212);

  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.font = "600 13px system-ui";
  const issued = `Issued: ${card.createdAt}`;
  ctx.fillText(issued, W - 140 - ctx.measureText(issued).width, 1212);

  ctx.globalAlpha = 0.12;
  ctx.fillStyle = "rgba(255,210,0,1)";
  ctx.font = "900 120px system-ui";
  ctx.fillText("☥", W - 220, H - 100);
  ctx.globalAlpha = 1;
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxW: number,
  lineH: number
) {
  const words = text.split(" ");
  let line = "";
  let yy = y;

  for (let i = 0; i < words.length; i++) {
    const test = line ? `${line} ${words[i]}` : words[i];
    if (ctx.measureText(test).width > maxW && line) {
      ctx.fillText(line, x, yy);
      line = words[i];
      yy += lineH;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new window.Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Image load failed"));
    img.src = src; // dataURL ok
  });
}
