import "./globals.css";
import type { Metadata } from "next";
import { Header } from "@/components/Header";

export const metadata: Metadata = {
  title: "The Yard — Yarden",
  description: "Sign up for show updates, news, and release info.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        {/* wrap it so we can hide it only when the intro exists */}
        <div className="siteHeader">
          <Header />
        </div>

        <main className="mx-auto w-full max-w-5xl px-4 pb-10 pt-10">{children}</main>
      </body>
    </html>
  );
}
