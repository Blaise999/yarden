"use client";

import LandingPage from "@/components/landing/LandingPage";

export default function HomePage() {
  return <LandingPage />;
}
