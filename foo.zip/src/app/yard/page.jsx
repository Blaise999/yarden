import React, { useState, useEffect, useCallback } from 'react';

// ============ DESIGN SYSTEM ============
const colors = {
  gold: '#FFD200',
  goldSoft: '#FFE150',
  amber: '#F5BE00',
  ink: '#0C0C0C',
  inkSoft: '#1C1C1C',
  paper: '#FFFAEB',
  paperWarm: '#FFF5DC',
};

// ============ INITIAL DATA ============
const initialSongs = [
  { id: '1', title: 'Wetin', year: '2022', streams: '60M+', cover: '🎵', links: { spotify: 'https://open.spotify.com/track/wetin', apple: '#', audiomack: '#' }, featured: true },
  { id: '2', title: 'Divine', year: '2023', streams: '5M+', cover: '✨', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: true },
  { id: '3', title: 'Busy Body', year: '2023', streams: '1.2M+', cover: '💃', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: false },
  { id: '4', title: 'Ifeoma (ft. Taves)', year: '2025', streams: '500K+', cover: '💕', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: true },
  { id: '5', title: 'Soul', year: '2024', streams: '800K+', cover: '🌙', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: false },
  { id: '6', title: 'Pressure', year: '2023', streams: '2M+', cover: '🔥', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: false },
  { id: '7', title: 'Wait', year: '2023', streams: '3M+', cover: '⏳', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: false },
  { id: '8', title: 'So Cold (ft. Swayvee & Morien)', year: '2023', streams: '1.5M+', cover: '❄️', links: { spotify: '#', apple: '#', audiomack: '#' }, featured: false },
];

const initialMerch = [
  { id: '1', name: 'The Descendant Hoodie', price: 15000, image: '🧥', description: 'Premium black hoodie with gold embroidery', inStock: true, category: 'clothing' },
  { id: '2', name: 'Yard Pass Tee', price: 8000, image: '👕', description: 'Limited edition concert tee', inStock: true, category: 'clothing' },
  { id: '3', name: 'Ankh Chain', price: 25000, image: '☥', description: 'Gold-plated ankh pendant', inStock: false, category: 'accessories' },
  { id: '4', name: 'TOWD Vinyl', price: 12000, image: '💿', description: 'The One Who Descends EP on vinyl', inStock: true, category: 'music' },
];

const initialVideos = [
  { id: '1', title: 'Wetin (Official Video)', youtubeId: 'dQw4w9WgXcQ', views: '2.5M', year: '2023' },
  { id: '2', title: 'Wild ft. Swayvee (Official Video)', youtubeId: 'dQw4w9WgXcQ', views: '500K', year: '2020' },
  { id: '3', title: 'Divine (Visualizer)', youtubeId: 'dQw4w9WgXcQ', views: '1.2M', year: '2023' },
  { id: '4', title: 'Busy Body (Official Video)', youtubeId: 'dQw4w9WgXcQ', views: '800K', year: '2023' },
];

const initialTickets = [
  { id: '1', event: 'The Yard Experience - Lagos', date: 'March 15, 2026', venue: 'Eko Convention Center', price: 'From ₦10,000', link: 'https://tickets.example.com', available: true },
  { id: '2', event: 'Afrobeats Festival - London', date: 'April 22, 2026', venue: 'O2 Academy Brixton', price: 'From £35', link: 'https://tickets.example.com', available: true },
];

// ============ MAIN APP ============
export default function YardenExperience() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [songs, setSongs] = useState(initialSongs);
  const [merch, setMerch] = useState(initialMerch);
  const [videos, setVideos] = useState(initialVideos);
  const [tickets, setTickets] = useState(initialTickets);
  const [passes, setPasses] = useState([]);
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState(null);

  // Load data from persistent storage
  useEffect(() => {
    const loadData = async () => {
      try {
        const [songsData, merchData, videosData, ticketsData, passesData] = await Promise.all([
          window.storage?.get('yarden-songs').catch(() => null),
          window.storage?.get('yarden-merch').catch(() => null),
          window.storage?.get('yarden-videos').catch(() => null),
          window.storage?.get('yarden-tickets').catch(() => null),
          window.storage?.get('yarden-passes').catch(() => null),
        ]);
        
        if (songsData?.value) setSongs(JSON.parse(songsData.value));
        if (merchData?.value) setMerch(JSON.parse(merchData.value));
        if (videosData?.value) setVideos(JSON.parse(videosData.value));
        if (ticketsData?.value) setTickets(JSON.parse(ticketsData.value));
        if (passesData?.value) setPasses(JSON.parse(passesData.value));
      } catch (e) {
        console.log('Storage not available, using defaults');
      }
      setLoading(false);
    };
    loadData();
  }, []);

  // Save data to persistent storage
  const saveData = useCallback(async (key, data) => {
    try {
      await window.storage?.set(key, JSON.stringify(data));
    } catch (e) {
      console.log('Storage save failed');
    }
  }, []);

  const showNotif = (msg, type = 'success') => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const addToCart = (item) => {
    setCart(prev => [...prev, { ...item, cartId: Date.now() }]);
    showNotif(`${item.name} added to cart!`);
  };

  const removeFromCart = (cartId) => {
    setCart(prev => prev.filter(i => i.cartId !== cartId));
  };

  const handleAdminLogin = () => {
    if (adminPassword === 'yarden2025') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminPassword('');
      showNotif('Welcome, Admin!');
    } else {
      showNotif('Invalid password', 'error');
    }
  };

  // ============ NAVIGATION ============
  const NavBar = () => (
    <nav style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 100,
      background: 'rgba(12, 12, 12, 0.95)',
      backdropFilter: 'blur(20px)',
      borderBottom: '1px solid rgba(255, 210, 0, 0.1)',
    }}>
      <div style={{
        maxWidth: 1400,
        margin: '0 auto',
        padding: '16px 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <button 
          onClick={() => setCurrentPage('home')}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <div style={{
            width: 44,
            height: 44,
            background: colors.gold,
            borderRadius: 12,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 24,
          }}>☥</div>
          <span style={{
            color: colors.gold,
            fontSize: 20,
            fontWeight: 900,
            letterSpacing: '-0.02em',
          }}>YARDEN</span>
        </button>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {['home', 'music', 'videos', 'merch', 'tickets'].map(page => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              style={{
                background: currentPage === page ? 'rgba(255, 210, 0, 0.15)' : 'transparent',
                border: 'none',
                padding: '10px 16px',
                borderRadius: 100,
                color: currentPage === page ? colors.gold : 'rgba(255, 255, 255, 0.6)',
                fontSize: 12,
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              {page}
            </button>
          ))}
          
          <div style={{ width: 1, height: 24, background: 'rgba(255, 255, 255, 0.1)', margin: '0 8px' }} />
          
          <button
            onClick={() => setCurrentPage('cart')}
            style={{
              background: cart.length > 0 ? colors.gold : 'rgba(255, 255, 255, 0.1)',
              border: 'none',
              padding: '10px 16px',
              borderRadius: 100,
              color: cart.length > 0 ? colors.ink : 'rgba(255, 255, 255, 0.6)',
              fontSize: 12,
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            🛒 {cart.length > 0 && `(${cart.length})`}
          </button>

          {isAdmin ? (
            <button
              onClick={() => setCurrentPage('admin')}
              style={{
                background: 'linear-gradient(135deg, #FFD200, #F5BE00)',
                border: 'none',
                padding: '10px 20px',
                borderRadius: 100,
                color: colors.ink,
                fontSize: 12,
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              ADMIN
            </button>
          ) : (
            <button
              onClick={() => setShowAdminLogin(true)}
              style={{
                background: 'transparent',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                padding: '10px 16px',
                borderRadius: 100,
                color: 'rgba(255, 255, 255, 0.5)',
                fontSize: 11,
                cursor: 'pointer',
              }}
            >
              🔐
            </button>
          )}
        </div>
      </div>
    </nav>
  );

  // ============ HOME PAGE ============
  const HomePage = () => (
    <div>
      {/* Hero Section */}
      <section style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse 80% 50% at 50% 0%, rgba(255, 210, 0, 0.15), transparent 70%)`,
        }} />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse 60% 80% at 80% 100%, rgba(255, 210, 0, 0.08), transparent 60%)`,
        }} />
        
        <div style={{ textAlign: 'center', zIndex: 1, padding: '120px 24px 80px' }}>
          <div style={{
            fontSize: 14,
            color: colors.gold,
            fontWeight: 700,
            letterSpacing: '0.3em',
            marginBottom: 24,
            textTransform: 'uppercase',
          }}>
            THE ONE WHO DESCENDS
          </div>
          
          <h1 style={{
            fontSize: 'clamp(80px, 20vw, 200px)',
            fontWeight: 900,
            color: 'white',
            letterSpacing: '-0.04em',
            lineHeight: 0.9,
            margin: 0,
            textShadow: '0 0 100px rgba(255, 210, 0, 0.3)',
          }}>
            YARDEN
          </h1>
          
          <p style={{
            fontSize: 18,
            color: 'rgba(255, 255, 255, 0.6)',
            maxWidth: 500,
            margin: '32px auto',
            lineHeight: 1.6,
          }}>
            Afrobeats artist from Lagos, Nigeria. 100M+ streams worldwide. 
            Music with a soul.
          </p>
          
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              onClick={() => setCurrentPage('music')}
              style={{
                background: colors.gold,
                border: 'none',
                padding: '16px 32px',
                borderRadius: 100,
                color: colors.ink,
                fontSize: 14,
                fontWeight: 700,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
              }}
            >
              ▶ LISTEN NOW
            </button>
            <button
              onClick={() => setCurrentPage('tickets')}
              style={{
                background: 'rgba(255, 255, 255, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                padding: '16px 32px',
                borderRadius: 100,
                color: 'white',
                fontSize: 14,
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              GET TICKETS
            </button>
          </div>
          
          {/* Streaming Stats */}
          <div style={{
            display: 'flex',
            gap: 48,
            justifyContent: 'center',
            marginTop: 64,
            flexWrap: 'wrap',
          }}>
            {[
              { label: 'STREAMS', value: '100M+' },
              { label: 'MONTHLY LISTENERS', value: '770K' },
              { label: 'COUNTRIES', value: '50+' },
            ].map(stat => (
              <div key={stat.label} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 36, fontWeight: 900, color: colors.gold }}>{stat.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255, 255, 255, 0.5)', letterSpacing: '0.15em', marginTop: 4 }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Songs */}
      <section style={{ padding: '80px 24px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 40 }}>
          <h2 style={{ fontSize: 32, fontWeight: 900, color: 'white', margin: 0 }}>Featured Tracks</h2>
          <button
            onClick={() => setCurrentPage('music')}
            style={{
              background: 'transparent',
              border: '1px solid rgba(255, 210, 0, 0.3)',
              padding: '10px 20px',
              borderRadius: 100,
              color: colors.gold,
              fontSize: 12,
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            VIEW ALL →
          </button>
        </div>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
          {songs.filter(s => s.featured).map(song => (
            <div
              key={song.id}
              style={{
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                borderRadius: 24,
                padding: 24,
                transition: 'all 0.3s',
                cursor: 'pointer',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(255, 210, 0, 0.05)';
                e.currentTarget.style.borderColor = 'rgba(255, 210, 0, 0.2)';
                e.currentTarget.style.transform = 'translateY(-4px)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.03)';
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.08)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{
                width: '100%',
                aspectRatio: '1',
                background: `linear-gradient(135deg, ${colors.inkSoft}, ${colors.ink})`,
                borderRadius: 16,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 64,
                marginBottom: 20,
              }}>
                {song.cover}
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 800, color: 'white', margin: '0 0 8px' }}>{song.title}</h3>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>{song.year}</span>
                <span style={{ fontSize: 13, color: colors.gold, fontWeight: 700 }}>{song.streams}</span>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <a href={song.links.spotify} target="_blank" rel="noopener noreferrer" style={{
                  flex: 1,
                  padding: '10px',
                  background: '#1DB954',
                  borderRadius: 8,
                  color: 'white',
                  fontSize: 11,
                  fontWeight: 700,
                  textAlign: 'center',
                  textDecoration: 'none',
                }}>SPOTIFY</a>
                <a href={song.links.apple} target="_blank" rel="noopener noreferrer" style={{
                  flex: 1,
                  padding: '10px',
                  background: 'rgba(255, 255, 255, 0.1)',
                  borderRadius: 8,
                  color: 'white',
                  fontSize: 11,
                  fontWeight: 700,
                  textAlign: 'center',
                  textDecoration: 'none',
                }}>APPLE</a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bio Section */}
      <section style={{
        padding: '100px 24px',
        background: 'linear-gradient(180deg, transparent, rgba(255, 210, 0, 0.03), transparent)',
      }}>
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <div style={{
            fontSize: 11,
            color: colors.gold,
            fontWeight: 700,
            letterSpacing: '0.3em',
            marginBottom: 16,
          }}>
            THE STORY
          </div>
          <h2 style={{ fontSize: 48, fontWeight: 900, color: 'white', margin: '0 0 32px', lineHeight: 1.1 }}>
            Born to make music that speaks to your soul
          </h2>
          <div style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: 17, lineHeight: 1.8 }}>
            <p style={{ marginBottom: 24 }}>
              Born as Okereke Blessed Jordan in Abia State, Nigeria, Yarden spent his formative years in Lagos. 
              Growing up in a household where his father was a part-time DJ and church choir singer, and his mother 
              a teacher who together hosted musical "jam" sessions at home, music was almost inevitable.
            </p>
            <p style={{ marginBottom: 24 }}>
              His breakout hit "Wetin" – remarkably recorded on just a mobile phone – went viral on TikTok in 2022, 
              amassing over 60 million streams on Spotify alone. The song's relatable lyrics and mellow vibe 
              resonated with millions, establishing Yarden as a newcomer to watch in the Afrobeats scene.
            </p>
            <p>
              In December 2023, he released his debut EP "The One Who Descends" – the title holds personal significance 
              as "Yarden" translates from Hebrew as "the one who descends." The project, released through Etins Records 
              in partnership with 0207 Def Jam, showcases his blend of Afrobeat, R&B, and pop influences.
            </p>
          </div>
          
          {/* Timeline */}
          <div style={{ marginTop: 64 }}>
            <div style={{ display: 'flex', gap: 32, overflowX: 'auto', padding: '20px 0' }}>
              {[
                { year: '2019', event: 'First recordings & freestyles' },
                { year: '2020', event: 'Signed to Etins Records' },
                { year: '2022', event: '"Wetin" goes viral' },
                { year: '2023', event: 'Debut EP release' },
                { year: '2025', event: 'International expansion' },
              ].map((item, i) => (
                <div key={i} style={{ minWidth: 200, textAlign: 'center' }}>
                  <div style={{
                    width: 16,
                    height: 16,
                    background: colors.gold,
                    borderRadius: '50%',
                    margin: '0 auto 16px',
                    boxShadow: '0 0 20px rgba(255, 210, 0, 0.5)',
                  }} />
                  <div style={{ fontSize: 24, fontWeight: 900, color: colors.gold }}>{item.year}</div>
                  <div style={{ fontSize: 14, color: 'rgba(255, 255, 255, 0.6)', marginTop: 8 }}>{item.event}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Placeholder */}
      <section style={{ padding: '80px 24px', maxWidth: 1200, margin: '0 auto' }}>
        <h2 style={{ fontSize: 32, fontWeight: 900, color: 'white', marginBottom: 40 }}>Gallery</h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gridTemplateRows: 'repeat(2, 200px)',
          gap: 16,
        }}>
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div
              key={i}
              style={{
                background: `linear-gradient(135deg, rgba(255, 210, 0, ${0.05 + i * 0.02}), rgba(255, 210, 0, 0.02))`,
                borderRadius: 16,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'rgba(255, 255, 255, 0.3)',
                fontSize: 14,
                gridColumn: i === 1 ? 'span 2' : i === 4 ? 'span 2' : 'span 1',
                border: '1px dashed rgba(255, 255, 255, 0.1)',
              }}
            >
              📷 Image {i}
            </div>
          ))}
        </div>
        <p style={{ color: 'rgba(255, 255, 255, 0.4)', fontSize: 13, marginTop: 16, textAlign: 'center' }}>
          Gallery images coming soon
        </p>
      </section>

      {/* Latest Video */}
      <section style={{ padding: '80px 24px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 40 }}>
          <h2 style={{ fontSize: 32, fontWeight: 900, color: 'white', margin: 0 }}>Latest Video</h2>
          <button
            onClick={() => setCurrentPage('videos')}
            style={{
              background: 'transparent',
              border: '1px solid rgba(255, 210, 0, 0.3)',
              padding: '10px 20px',
              borderRadius: 100,
              color: colors.gold,
              fontSize: 12,
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            ALL VIDEOS →
          </button>
        </div>
        
        {videos[0] && (
          <div style={{
            background: 'rgba(255, 255, 255, 0.03)',
            borderRadius: 24,
            overflow: 'hidden',
            border: '1px solid rgba(255, 255, 255, 0.08)',
          }}>
            <div style={{
              aspectRatio: '16/9',
              background: colors.inkSoft,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <a
                href={`https://youtube.com/watch?v=${videos[0].youtubeId}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  width: 80,
                  height: 80,
                  background: 'rgba(255, 0, 0, 0.9)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 32,
                  textDecoration: 'none',
                  transition: 'transform 0.2s',
                }}
                onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.1)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
              >
                ▶️
              </a>
            </div>
            <div style={{ padding: 24 }}>
              <h3 style={{ fontSize: 20, fontWeight: 800, color: 'white', margin: 0 }}>{videos[0].title}</h3>
              <p style={{ color: 'rgba(255, 255, 255, 0.5)', fontSize: 14, marginTop: 8 }}>
                {videos[0].views} views • {videos[0].year}
              </p>
            </div>
          </div>
        )}
      </section>

      {/* Social Links */}
      <section style={{ padding: '80px 24px', textAlign: 'center' }}>
        <h2 style={{ fontSize: 24, fontWeight: 900, color: 'white', marginBottom: 32 }}>Follow Yarden</h2>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          {[
            { name: 'Instagram', handle: '@thisisyarden', icon: '📸' },
            { name: 'TikTok', handle: '@thisisyarden', icon: '🎵' },
            { name: 'Twitter/X', handle: '@thisisyarden', icon: '𝕏' },
            { name: 'YouTube', handle: 'Yarden', icon: '▶️' },
          ].map(social => (
            <a
              key={social.name}
              href="#"
              style={{
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: 16,
                padding: '20px 32px',
                textDecoration: 'none',
                transition: 'all 0.2s',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(255, 210, 0, 0.1)';
                e.currentTarget.style.borderColor = 'rgba(255, 210, 0, 0.3)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
              }}
            >
              <div style={{ fontSize: 24, marginBottom: 8 }}>{social.icon}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'white' }}>{social.name}</div>
              <div style={{ fontSize: 12, color: 'rgba(255, 255, 255, 0.5)' }}>{social.handle}</div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );

  // ============ MUSIC PAGE ============
  const MusicPage = () => (
    <div style={{ padding: '120px 24px 80px', maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 16 }}>Discography</h1>
      <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 17, marginBottom: 48 }}>
        All tracks available on every streaming platform
      </p>
      
      {/* EP Highlight */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(255, 210, 0, 0.1), rgba(255, 210, 0, 0.02))',
        borderRadius: 32,
        padding: 40,
        marginBottom: 48,
        border: '1px solid rgba(255, 210, 0, 0.2)',
        display: 'flex',
        gap: 40,
        alignItems: 'center',
        flexWrap: 'wrap',
      }}>
        <div style={{
          width: 200,
          height: 200,
          background: colors.ink,
          borderRadius: 20,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 80,
          flexShrink: 0,
        }}>
          ☥
        </div>
        <div style={{ flex: 1, minWidth: 280 }}>
          <div style={{ fontSize: 11, color: colors.gold, fontWeight: 700, letterSpacing: '0.2em', marginBottom: 8 }}>
            DEBUT EP • 2023
          </div>
          <h2 style={{ fontSize: 36, fontWeight: 900, color: 'white', margin: '0 0 16px' }}>
            The One Who Descends
          </h2>
          <p style={{ color: 'rgba(255, 255, 255, 0.6)', marginBottom: 24, lineHeight: 1.6 }}>
            A 5-track journey through Afrobeat, R&B, and pop. Features "Divine", "Wait", "Pressure", and more.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <a href="#" style={{
              background: '#1DB954',
              padding: '12px 24px',
              borderRadius: 100,
              color: 'white',
              fontWeight: 700,
              fontSize: 13,
              textDecoration: 'none',
            }}>Stream on Spotify</a>
            <a href="#" style={{
              background: 'rgba(255, 255, 255, 0.1)',
              padding: '12px 24px',
              borderRadius: 100,
              color: 'white',
              fontWeight: 700,
              fontSize: 13,
              textDecoration: 'none',
            }}>Apple Music</a>
          </div>
        </div>
      </div>

      {/* All Songs */}
      <h3 style={{ fontSize: 24, fontWeight: 800, color: 'white', marginBottom: 24 }}>All Tracks</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {songs.map((song, i) => (
          <div
            key={song.id}
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 16,
              padding: '16px 24px',
              display: 'flex',
              alignItems: 'center',
              gap: 20,
              border: '1px solid rgba(255, 255, 255, 0.06)',
              transition: 'all 0.2s',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.06)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.03)';
            }}
          >
            <span style={{ color: 'rgba(255, 255, 255, 0.3)', fontSize: 14, fontWeight: 700, width: 30 }}>
              {String(i + 1).padStart(2, '0')}
            </span>
            <span style={{ fontSize: 32 }}>{song.cover}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: 'white' }}>{song.title}</div>
              <div style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>{song.year}</div>
            </div>
            <div style={{ fontSize: 14, color: colors.gold, fontWeight: 700, marginRight: 20 }}>
              {song.streams}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <a href={song.links.spotify} target="_blank" rel="noopener noreferrer" style={{
                width: 36,
                height: 36,
                background: '#1DB954',
                borderRadius: 8,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 14,
                textDecoration: 'none',
              }}>🎧</a>
              <a href={song.links.apple} target="_blank" rel="noopener noreferrer" style={{
                width: 36,
                height: 36,
                background: 'rgba(255, 255, 255, 0.1)',
                borderRadius: 8,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 14,
                textDecoration: 'none',
              }}>🍎</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ============ VIDEOS PAGE ============
  const VideosPage = () => (
    <div style={{ padding: '120px 24px 80px', maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 16 }}>Videos</h1>
      <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 17, marginBottom: 48 }}>
        Official music videos and visualizers
      </p>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: 24 }}>
        {videos.map(video => (
          <a
            key={video.id}
            href={`https://youtube.com/watch?v=${video.youtubeId}`}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 20,
              overflow: 'hidden',
              textDecoration: 'none',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              transition: 'all 0.3s',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'translateY(-4px)';
              e.currentTarget.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.3)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <div style={{
              aspectRatio: '16/9',
              background: colors.inkSoft,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
            }}>
              <div style={{
                width: 60,
                height: 60,
                background: 'rgba(255, 0, 0, 0.9)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 24,
              }}>▶️</div>
              <div style={{
                position: 'absolute',
                bottom: 8,
                right: 8,
                background: 'rgba(0, 0, 0, 0.8)',
                padding: '4px 8px',
                borderRadius: 4,
                fontSize: 12,
                color: 'white',
              }}>
                YouTube
              </div>
            </div>
            <div style={{ padding: 20 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: 'white', margin: 0 }}>{video.title}</h3>
              <p style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)', marginTop: 8 }}>
                {video.views} views • {video.year}
              </p>
            </div>
          </a>
        ))}
      </div>
    </div>
  );

  // ============ MERCH PAGE ============
  const MerchPage = () => (
    <div style={{ padding: '120px 24px 80px', maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 16 }}>Merch</h1>
      <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 17, marginBottom: 48 }}>
        Official Yarden merchandise
      </p>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 24 }}>
        {merch.map(item => (
          <div
            key={item.id}
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 24,
              overflow: 'hidden',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              transition: 'all 0.3s',
            }}
          >
            <div style={{
              aspectRatio: '1',
              background: `linear-gradient(135deg, ${colors.inkSoft}, ${colors.ink})`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 80,
              position: 'relative',
            }}>
              {item.image}
              {!item.inStock && (
                <div style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'rgba(0, 0, 0, 0.7)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <span style={{
                    background: 'rgba(255, 255, 255, 0.1)',
                    padding: '8px 16px',
                    borderRadius: 100,
                    color: 'white',
                    fontSize: 12,
                    fontWeight: 700,
                  }}>SOLD OUT</span>
                </div>
              )}
            </div>
            <div style={{ padding: 24 }}>
              <div style={{
                fontSize: 11,
                color: colors.gold,
                fontWeight: 700,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                marginBottom: 8,
              }}>
                {item.category}
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 800, color: 'white', margin: '0 0 8px' }}>{item.name}</h3>
              <p style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)', marginBottom: 16, lineHeight: 1.5 }}>
                {item.description}
              </p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 24, fontWeight: 900, color: colors.gold }}>
                  ₦{item.price.toLocaleString()}
                </span>
                <button
                  onClick={() => item.inStock && addToCart(item)}
                  disabled={!item.inStock}
                  style={{
                    background: item.inStock ? colors.gold : 'rgba(255, 255, 255, 0.1)',
                    border: 'none',
                    padding: '12px 24px',
                    borderRadius: 100,
                    color: item.inStock ? colors.ink : 'rgba(255, 255, 255, 0.3)',
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: item.inStock ? 'pointer' : 'not-allowed',
                  }}
                >
                  {item.inStock ? 'ADD TO CART' : 'SOLD OUT'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ============ TICKETS PAGE ============
  const TicketsPage = () => (
    <div style={{ padding: '120px 24px 80px', maxWidth: 1000, margin: '0 auto' }}>
      <h1 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 16 }}>Tour & Tickets</h1>
      <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 17, marginBottom: 48 }}>
        Catch Yarden live. Tickets available through official partners.
      </p>
      
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {tickets.map(ticket => (
          <div
            key={ticket.id}
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 24,
              padding: 32,
              border: '1px solid rgba(255, 255, 255, 0.08)',
              display: 'flex',
              alignItems: 'center',
              gap: 32,
              flexWrap: 'wrap',
            }}
          >
            <div style={{
              width: 80,
              height: 80,
              background: 'linear-gradient(135deg, rgba(255, 210, 0, 0.2), rgba(255, 210, 0, 0.05))',
              borderRadius: 16,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}>
              <span style={{ fontSize: 24, fontWeight: 900, color: colors.gold }}>
                {ticket.date.split(' ')[1]?.replace(',', '')}
              </span>
              <span style={{ fontSize: 12, color: 'rgba(255, 255, 255, 0.5)', textTransform: 'uppercase' }}>
                {ticket.date.split(' ')[0]}
              </span>
            </div>
            
            <div style={{ flex: 1, minWidth: 200 }}>
              <h3 style={{ fontSize: 20, fontWeight: 800, color: 'white', margin: '0 0 8px' }}>{ticket.event}</h3>
              <p style={{ fontSize: 14, color: 'rgba(255, 255, 255, 0.5)', margin: 0 }}>
                📍 {ticket.venue}
              </p>
            </div>
            
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: colors.gold, marginBottom: 12 }}>
                {ticket.price}
              </div>
              <a
                href={ticket.link}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: 'inline-block',
                  background: ticket.available ? colors.gold : 'rgba(255, 255, 255, 0.1)',
                  padding: '14px 28px',
                  borderRadius: 100,
                  color: ticket.available ? colors.ink : 'rgba(255, 255, 255, 0.3)',
                  fontSize: 13,
                  fontWeight: 700,
                  textDecoration: 'none',
                }}
              >
                {ticket.available ? 'GET TICKETS →' : 'SOLD OUT'}
              </a>
            </div>
          </div>
        ))}
      </div>
      
      <div style={{
        marginTop: 48,
        padding: 32,
        background: 'rgba(255, 210, 0, 0.05)',
        borderRadius: 20,
        border: '1px solid rgba(255, 210, 0, 0.15)',
        textAlign: 'center',
      }}>
        <p style={{ color: 'rgba(255, 255, 255, 0.7)', margin: 0 }}>
          🎫 Tickets are sold through our official ticketing partners. We do not sell tickets directly on this site.
        </p>
      </div>
    </div>
  );

  // ============ CART PAGE ============
  const CartPage = () => {
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    
    return (
      <div style={{ padding: '120px 24px 80px', maxWidth: 800, margin: '0 auto' }}>
        <h1 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 48 }}>Your Cart</h1>
        
        {cart.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: 80,
            background: 'rgba(255, 255, 255, 0.03)',
            borderRadius: 24,
            border: '1px solid rgba(255, 255, 255, 0.08)',
          }}>
            <div style={{ fontSize: 64, marginBottom: 24 }}>🛒</div>
            <h3 style={{ fontSize: 24, fontWeight: 800, color: 'white', margin: '0 0 16px' }}>Your cart is empty</h3>
            <p style={{ color: 'rgba(255, 255, 255, 0.5)', marginBottom: 32 }}>Add some merch to get started!</p>
            <button
              onClick={() => setCurrentPage('merch')}
              style={{
                background: colors.gold,
                border: 'none',
                padding: '14px 28px',
                borderRadius: 100,
                color: colors.ink,
                fontSize: 14,
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              BROWSE MERCH
            </button>
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {cart.map(item => (
                <div
                  key={item.cartId}
                  style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    borderRadius: 16,
                    padding: 20,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 20,
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                  }}
                >
                  <div style={{
                    width: 60,
                    height: 60,
                    background: colors.inkSoft,
                    borderRadius: 12,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 32,
                  }}>
                    {item.image}
                  </div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ fontSize: 16, fontWeight: 700, color: 'white', margin: 0 }}>{item.name}</h4>
                    <p style={{ fontSize: 14, color: 'rgba(255, 255, 255, 0.5)', margin: '4px 0 0' }}>
                      ₦{item.price.toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.cartId)}
                    style={{
                      background: 'rgba(255, 100, 100, 0.1)',
                      border: 'none',
                      width: 40,
                      height: 40,
                      borderRadius: 10,
                      color: '#ff6464',
                      cursor: 'pointer',
                      fontSize: 18,
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            
            <div style={{
              marginTop: 32,
              padding: 24,
              background: 'rgba(255, 210, 0, 0.05)',
              borderRadius: 20,
              border: '1px solid rgba(255, 210, 0, 0.15)',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <span style={{ fontSize: 18, color: 'rgba(255, 255, 255, 0.7)' }}>Total</span>
                <span style={{ fontSize: 28, fontWeight: 900, color: colors.gold }}>₦{total.toLocaleString()}</span>
              </div>
              <button
                onClick={() => showNotif('Checkout coming soon!')}
                style={{
                  width: '100%',
                  background: colors.gold,
                  border: 'none',
                  padding: '16px',
                  borderRadius: 100,
                  color: colors.ink,
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                PROCEED TO CHECKOUT
              </button>
            </div>
          </>
        )}
      </div>
    );
  };

  // ============ ADMIN PAGE ============
  const AdminPage = () => {
    const [adminTab, setAdminTab] = useState('passes');
    const [editingSong, setEditingSong] = useState(null);
    const [editingMerch, setEditingMerch] = useState(null);
    const [newSong, setNewSong] = useState({ title: '', year: '', streams: '', cover: '🎵', links: { spotify: '', apple: '', audiomack: '' }, featured: false });
    const [newMerch, setNewMerch] = useState({ name: '', price: '', image: '🎁', description: '', inStock: true, category: 'clothing' });

    const handleAddSong = async () => {
      if (!newSong.title) return;
      const updated = [...songs, { ...newSong, id: Date.now().toString() }];
      setSongs(updated);
      await saveData('yarden-songs', updated);
      setNewSong({ title: '', year: '', streams: '', cover: '🎵', links: { spotify: '', apple: '', audiomack: '' }, featured: false });
      showNotif('Song added!');
    };

    const handleDeleteSong = async (id) => {
      const updated = songs.filter(s => s.id !== id);
      setSongs(updated);
      await saveData('yarden-songs', updated);
      showNotif('Song deleted');
    };

    const handleAddMerch = async () => {
      if (!newMerch.name) return;
      const updated = [...merch, { ...newMerch, id: Date.now().toString(), price: Number(newMerch.price) }];
      setMerch(updated);
      await saveData('yarden-merch', updated);
      setNewMerch({ name: '', price: '', image: '🎁', description: '', inStock: true, category: 'clothing' });
      showNotif('Merch added!');
    };

    const handleDeleteMerch = async (id) => {
      const updated = merch.filter(m => m.id !== id);
      setMerch(updated);
      await saveData('yarden-merch', updated);
      showNotif('Merch deleted');
    };

    const handleToggleMerchStock = async (id) => {
      const updated = merch.map(m => m.id === id ? { ...m, inStock: !m.inStock } : m);
      setMerch(updated);
      await saveData('yarden-merch', updated);
    };

    const inputStyle = {
      width: '100%',
      padding: '12px 16px',
      background: 'rgba(255, 255, 255, 0.05)',
      border: '1px solid rgba(255, 255, 255, 0.1)',
      borderRadius: 12,
      color: 'white',
      fontSize: 14,
      outline: 'none',
    };

    return (
      <div style={{ padding: '120px 24px 80px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
          <div>
            <h1 style={{ fontSize: 36, fontWeight: 900, color: 'white', margin: '0 0 8px' }}>Admin Dashboard</h1>
            <p style={{ color: 'rgba(255, 255, 255, 0.5)', margin: 0 }}>Manage your content</p>
          </div>
          <button
            onClick={() => { setIsAdmin(false); setCurrentPage('home'); }}
            style={{
              background: 'rgba(255, 100, 100, 0.1)',
              border: '1px solid rgba(255, 100, 100, 0.2)',
              padding: '10px 20px',
              borderRadius: 100,
              color: '#ff6464',
              fontSize: 12,
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            LOGOUT
          </button>
        </div>

        {/* Admin Tabs */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 32, flexWrap: 'wrap' }}>
          {['passes', 'songs', 'merch', 'videos', 'tickets'].map(tab => (
            <button
              key={tab}
              onClick={() => setAdminTab(tab)}
              style={{
                background: adminTab === tab ? colors.gold : 'rgba(255, 255, 255, 0.05)',
                border: 'none',
                padding: '12px 24px',
                borderRadius: 100,
                color: adminTab === tab ? colors.ink : 'rgba(255, 255, 255, 0.6)',
                fontSize: 13,
                fontWeight: 700,
                textTransform: 'uppercase',
                cursor: 'pointer',
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Passes Tab */}
        {adminTab === 'passes' && (
          <div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
              gap: 16,
              marginBottom: 32,
            }}>
              <div style={{
                background: 'rgba(255, 210, 0, 0.1)',
                borderRadius: 16,
                padding: 20,
                textAlign: 'center',
              }}>
                <div style={{ fontSize: 32, fontWeight: 900, color: colors.gold }}>{passes.length}</div>
                <div style={{ fontSize: 12, color: 'rgba(255, 255, 255, 0.5)', marginTop: 4 }}>Total Passes</div>
              </div>
            </div>
            
            {passes.length === 0 ? (
              <div style={{
                textAlign: 'center',
                padding: 60,
                background: 'rgba(255, 255, 255, 0.03)',
                borderRadius: 20,
              }}>
                <p style={{ color: 'rgba(255, 255, 255, 0.5)' }}>No passes generated yet</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {passes.map(pass => (
                  <div
                    key={pass.id}
                    style={{
                      background: 'rgba(255, 255, 255, 0.03)',
                      borderRadius: 12,
                      padding: 16,
                      display: 'flex',
                      alignItems: 'center',
                      gap: 16,
                      border: '1px solid rgba(255, 255, 255, 0.06)',
                    }}
                  >
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, color: 'white' }}>{pass.name}</div>
                      <div style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>{pass.email}</div>
                    </div>
                    <div style={{ fontSize: 12, color: 'rgba(255, 255, 255, 0.4)' }}>{pass.createdAt}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Songs Tab */}
        {adminTab === 'songs' && (
          <div>
            {/* Add New Song Form */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 20,
              padding: 24,
              marginBottom: 32,
              border: '1px solid rgba(255, 255, 255, 0.08)',
            }}>
              <h3 style={{ fontSize: 18, fontWeight: 800, color: 'white', marginBottom: 20 }}>Add New Song</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
                <input
                  type="text"
                  placeholder="Song Title"
                  value={newSong.title}
                  onChange={e => setNewSong({ ...newSong, title: e.target.value })}
                  style={inputStyle}
                />
                <input
                  type="text"
                  placeholder="Year (e.g. 2024)"
                  value={newSong.year}
                  onChange={e => setNewSong({ ...newSong, year: e.target.value })}
                  style={inputStyle}
                />
                <input
                  type="text"
                  placeholder="Streams (e.g. 1M+)"
                  value={newSong.streams}
                  onChange={e => setNewSong({ ...newSong, streams: e.target.value })}
                  style={inputStyle}
                />
                <input
                  type="text"
                  placeholder="Spotify Link"
                  value={newSong.links.spotify}
                  onChange={e => setNewSong({ ...newSong, links: { ...newSong.links, spotify: e.target.value } })}
                  style={inputStyle}
                />
                <input
                  type="text"
                  placeholder="Apple Music Link"
                  value={newSong.links.apple}
                  onChange={e => setNewSong({ ...newSong, links: { ...newSong.links, apple: e.target.value } })}
                  style={inputStyle}
                />
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'white', fontSize: 14 }}>
                  <input
                    type="checkbox"
                    checked={newSong.featured}
                    onChange={e => setNewSong({ ...newSong, featured: e.target.checked })}
                  />
                  Featured
                </label>
              </div>
              <button
                onClick={handleAddSong}
                style={{
                  marginTop: 20,
                  background: colors.gold,
                  border: 'none',
                  padding: '12px 24px',
                  borderRadius: 100,
                  color: colors.ink,
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                ADD SONG
              </button>
            </div>

            {/* Songs List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {songs.map(song => (
                <div
                  key={song.id}
                  style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    borderRadius: 12,
                    padding: 16,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 16,
                    border: '1px solid rgba(255, 255, 255, 0.06)',
                  }}
                >
                  <span style={{ fontSize: 24 }}>{song.cover}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: 'white' }}>
                      {song.title}
                      {song.featured && <span style={{ marginLeft: 8, fontSize: 10, color: colors.gold }}>★ FEATURED</span>}
                    </div>
                    <div style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>{song.year} • {song.streams}</div>
                  </div>
                  <button
                    onClick={() => handleDeleteSong(song.id)}
                    style={{
                      background: 'rgba(255, 100, 100, 0.1)',
                      border: 'none',
                      width: 36,
                      height: 36,
                      borderRadius: 8,
                      color: '#ff6464',
                      cursor: 'pointer',
                    }}
                  >
                    🗑
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Merch Tab */}
        {adminTab === 'merch' && (
          <div>
            {/* Add New Merch Form */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 20,
              padding: 24,
              marginBottom: 32,
              border: '1px solid rgba(255, 255, 255, 0.08)',
            }}>
              <h3 style={{ fontSize: 18, fontWeight: 800, color: 'white', marginBottom: 20 }}>Add New Merch</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
                <input
                  type="text"
                  placeholder="Product Name"
                  value={newMerch.name}
                  onChange={e => setNewMerch({ ...newMerch, name: e.target.value })}
                  style={inputStyle}
                />
                <input
                  type="number"
                  placeholder="Price (NGN)"
                  value={newMerch.price}
                  onChange={e => setNewMerch({ ...newMerch, price: e.target.value })}
                  style={inputStyle}
                />
                <input
                  type="text"
                  placeholder="Emoji Icon (e.g. 👕)"
                  value={newMerch.image}
                  onChange={e => setNewMerch({ ...newMerch, image: e.target.value })}
                  style={inputStyle}
                />
                <select
                  value={newMerch.category}
                  onChange={e => setNewMerch({ ...newMerch, category: e.target.value })}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="clothing">Clothing</option>
                  <option value="accessories">Accessories</option>
                  <option value="music">Music</option>
                  <option value="other">Other</option>
                </select>
                <input
                  type="text"
                  placeholder="Description"
                  value={newMerch.description}
                  onChange={e => setNewMerch({ ...newMerch, description: e.target.value })}
                  style={{ ...inputStyle, gridColumn: 'span 2' }}
                />
              </div>
              <button
                onClick={handleAddMerch}
                style={{
                  marginTop: 20,
                  background: colors.gold,
                  border: 'none',
                  padding: '12px 24px',
                  borderRadius: 100,
                  color: colors.ink,
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                ADD MERCH
              </button>
            </div>

            {/* Merch List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {merch.map(item => (
                <div
                  key={item.id}
                  style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    borderRadius: 12,
                    padding: 16,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 16,
                    border: '1px solid rgba(255, 255, 255, 0.06)',
                  }}
                >
                  <span style={{ fontSize: 32 }}>{item.image}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: 'white' }}>{item.name}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>
                      ₦{item.price.toLocaleString()} • {item.category}
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleMerchStock(item.id)}
                    style={{
                      background: item.inStock ? 'rgba(100, 255, 100, 0.1)' : 'rgba(255, 100, 100, 0.1)',
                      border: 'none',
                      padding: '8px 16px',
                      borderRadius: 100,
                      color: item.inStock ? '#64ff64' : '#ff6464',
                      fontSize: 11,
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    {item.inStock ? 'IN STOCK' : 'SOLD OUT'}
                  </button>
                  <button
                    onClick={() => handleDeleteMerch(item.id)}
                    style={{
                      background: 'rgba(255, 100, 100, 0.1)',
                      border: 'none',
                      width: 36,
                      height: 36,
                      borderRadius: 8,
                      color: '#ff6464',
                      cursor: 'pointer',
                    }}
                  >
                    🗑
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Videos Tab */}
        {adminTab === 'videos' && (
          <div style={{
            textAlign: 'center',
            padding: 60,
            background: 'rgba(255, 255, 255, 0.03)',
            borderRadius: 20,
          }}>
            <p style={{ color: 'rgba(255, 255, 255, 0.5)' }}>Video management coming soon</p>
          </div>
        )}

        {/* Tickets Tab */}
        {adminTab === 'tickets' && (
          <div style={{
            textAlign: 'center',
            padding: 60,
            background: 'rgba(255, 255, 255, 0.03)',
            borderRadius: 20,
          }}>
            <p style={{ color: 'rgba(255, 255, 255, 0.5)' }}>Ticket management coming soon</p>
          </div>
        )}
      </div>
    );
  };

  // ============ ADMIN LOGIN MODAL ============
  const AdminLoginModal = () => (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0, 0, 0, 0.8)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 200,
        padding: 24,
      }}
      onClick={() => setShowAdminLogin(false)}
    >
      <div
        style={{
          background: colors.inkSoft,
          borderRadius: 24,
          padding: 40,
          maxWidth: 400,
          width: '100%',
          border: '1px solid rgba(255, 210, 0, 0.2)',
        }}
        onClick={e => e.stopPropagation()}
      >
        <div style={{
          width: 60,
          height: 60,
          background: colors.gold,
          borderRadius: 16,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 28,
          margin: '0 auto 24px',
        }}>
          🔐
        </div>
        <h2 style={{ fontSize: 24, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 8 }}>
          Admin Access
        </h2>
        <p style={{ color: 'rgba(255, 255, 255, 0.5)', textAlign: 'center', marginBottom: 32 }}>
          Enter password to continue
        </p>
        <input
          type="password"
          placeholder="Password"
          value={adminPassword}
          onChange={e => setAdminPassword(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleAdminLogin()}
          style={{
            width: '100%',
            padding: '16px 20px',
            background: 'rgba(255, 255, 255, 0.05)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: 12,
            color: 'white',
            fontSize: 16,
            outline: 'none',
            marginBottom: 16,
            boxSizing: 'border-box',
          }}
          autoFocus
        />
        <button
          onClick={handleAdminLogin}
          style={{
            width: '100%',
            background: colors.gold,
            border: 'none',
            padding: '16px',
            borderRadius: 100,
            color: colors.ink,
            fontSize: 14,
            fontWeight: 700,
            cursor: 'pointer',
          }}
        >
          LOGIN
        </button>
        <p style={{ fontSize: 12, color: 'rgba(255, 255, 255, 0.3)', textAlign: 'center', marginTop: 16 }}>
          Demo password: yarden2025
        </p>
      </div>
    </div>
  );

  // ============ NOTIFICATION ============
  const Notification = () => notification && (
    <div style={{
      position: 'fixed',
      bottom: 24,
      right: 24,
      background: notification.type === 'error' ? '#ff4444' : colors.gold,
      color: notification.type === 'error' ? 'white' : colors.ink,
      padding: '16px 24px',
      borderRadius: 12,
      fontWeight: 700,
      fontSize: 14,
      zIndex: 300,
      boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)',
      animation: 'slideIn 0.3s ease',
    }}>
      {notification.msg}
    </div>
  );

  // ============ RENDER ============
  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: colors.ink,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: 60,
            height: 60,
            background: colors.gold,
            borderRadius: 16,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 32,
            margin: '0 auto 24px',
            animation: 'pulse 1s ease infinite',
          }}>
            ☥
          </div>
          <p style={{ color: 'rgba(255, 255, 255, 0.5)' }}>Loading...</p>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'music': return <MusicPage />;
      case 'videos': return <VideosPage />;
      case 'merch': return <MerchPage />;
      case 'tickets': return <TicketsPage />;
      case 'cart': return <CartPage />;
      case 'admin': return isAdmin ? <AdminPage /> : <HomePage />;
      default: return <HomePage />;
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: colors.ink,
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::selection { background: rgba(255, 210, 0, 0.3); }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        input::placeholder { color: rgba(255, 255, 255, 0.3); }
        select { appearance: none; }
        a { transition: all 0.2s; }
      `}</style>
      
      <NavBar />
      {renderPage()}
      
      {showAdminLogin && <AdminLoginModal />}
      <Notification />
      
      {/* Footer */}
      <footer style={{
        padding: '48px 24px',
        borderTop: '1px solid rgba(255, 255, 255, 0.05)',
        textAlign: 'center',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 12,
          marginBottom: 16,
        }}>
          <div style={{
            width: 32,
            height: 32,
            background: colors.gold,
            borderRadius: 8,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 16,
          }}>☥</div>
          <span style={{ color: colors.gold, fontWeight: 800 }}>YARDEN</span>
        </div>
        <p style={{ color: 'rgba(255, 255, 255, 0.3)', fontSize: 13 }}>
          © 2025 Yarden. All rights reserved. Etins Records / 0207 Def Jam
        </p>
      </footer>
    </div>
  );
}
