"use client";

import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  motion,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  useMotionValue,
} from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

type Gender = "male" | "female" | "";
type PassCard = {
  id: string;
  name: string;
  email: string;
  phone: string;
  houseLabel: "Descendant" | "Angel";
  createdAt: string;
  photoDataUrl?: string;
};

export default function HomePage() {
  const prefersReduced = useReducedMotion();

  // ===== GSAP INTRO (yards.png -> dissolve -> hero) =====
  const pinRef = useRef<HTMLElement | null>(null);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const overlayImgRef = useRef<HTMLDivElement | null>(null);
  const heroRevealRef = useRef<HTMLDivElement | null>(null);
  const navDarkRef = useRef<HTMLDivElement | null>(null);
  const navLightRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (prefersReduced) return;
    if (
      !pinRef.current ||
      !overlayRef.current ||
      !overlayImgRef.current ||
      !heroRevealRef.current
    )
      return;

    const ctx = gsap.context(() => {
      gsap.set(heroRevealRef.current, { opacity: 0, y: 26, filter: "blur(8px)" });
      gsap.set(overlayRef.current, { opacity: 1 });
      gsap.set(navDarkRef.current, { opacity: 1 });
      gsap.set(navLightRef.current, { opacity: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: pinRef.current!,
          start: "top top",
          end: "+=140%",
          scrub: true,
          pin: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Image feels "alive" while it dissolves
      tl.to(
        overlayImgRef.current!,
        { scale: 1.08, filter: "blur(18px)", duration: 1, ease: "none" },
        0
      );

      // Dissolve layer (fade)
      tl.to(overlayRef.current!, { opacity: 0, duration: 1, ease: "none" }, 0.15);

      // Nav swaps from white-on-photo to black-on-hero
      tl.to(navDarkRef.current!, { opacity: 0, duration: 0.35, ease: "none" }, 0.18);
      tl.to(navLightRef.current!, { opacity: 1, duration: 0.35, ease: "none" }, 0.38);

      // Hero reveals
      tl.to(
        heroRevealRef.current!,
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1, ease: "none" },
        0.28
      );
    }, pinRef);

    return () => ctx.revert();
  }, [prefersReduced]);

  // Refresh ScrollTrigger once the hero image is loaded (prevents jumpy pin)
  const refreshST = () => {
    if (prefersReduced) return;
    requestAnimationFrame(() => ScrollTrigger.refresh());
  };

  // ===== Your existing hero parallax (kept) =====
  const heroParallaxRef = useRef<HTMLElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: heroParallaxRef,
    offset: ["start end", "end start"],
  });

  const wmY = useTransform(scrollYProgress, [0, 1], prefersReduced ? [0, 0] : [30, -30]);
  const galleryY = useTransform(
    scrollYProgress,
    [0, 1],
    prefersReduced ? [0, 0] : [22, -22]
  );

  // ===== Cursor glow (kept) =====
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const gx = useSpring(mx, { stiffness: 240, damping: 32, mass: 0.35 });
  const gy = useSpring(my, { stiffness: 240, damping: 32, mass: 0.35 });

  const posters = useMemo(
    () => [
      { src: "/Pictures/yarden1.png", label: "Yarden • Portrait 01" },
      { src: "/Pictures/yarden2.png", label: "Yarden • Portrait 02" },
      { src: "/Pictures/yarden3.png", label: "Yarden • Portrait 03" },
      { src: "/Pictures/yarden4.png", label: "Studio / Wide Cover", wide: true },
    ],
    []
  );

  return (
    <div className="space-y-14">
      {/* ========================= */}
      {/* GSAP INTRO PINNED SEQUENCE */}
      {/* ========================= */}
      <section
        ref={(n) => {
          pinRef.current = n;
        }}
        className={[
          // FULL-BLEED breakout (even inside max-w layouts)
          "introPin relative max-w-none overflow-hidden",
          "w-screen left-1/2 right-1/2 -ml-[50vw] -mr-[50vw]",
          // You can keep a premium frame on desktop
          "rounded-none md:rounded-[44px] md:border md:border-black/10",
          "shadow-[0_30px_140px_rgba(0,0,0,0.18)]",
        ].join(" ")}
      >
        {/* HERO LAYER (revealed after dissolve) */}
        <div ref={heroRevealRef} className="relative">
          <section
            ref={(n) => {
              heroParallaxRef.current = n;
            }}
            onPointerMove={(e) => {
              const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
              mx.set(e.clientX - r.left);
              my.set(e.clientY - r.top);
            }}
            className="heroStage relative overflow-hidden bg-yellow-200/15"
          >
            {/* wallpaper + depth */}
            <div className="absolute inset-0 ankh-wall" />
            <div className="absolute inset-0 microgrid opacity-[0.22]" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/18" />
            <div className="absolute inset-0 vignette" />
            <div className="absolute inset-0 grain opacity-[0.20]" />

            {/* cursor spotlight */}
            <motion.div
              aria-hidden
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
              style={{ left: gx, top: gy }}
            >
              <div className="h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle,rgba(255,210,0,0.32),rgba(255,210,0,0.10),rgba(255,210,0,0))] blur-2xl" />
            </motion.div>

            {/* watermark */}
            <motion.div
              aria-hidden
              className="pointer-events-none absolute -left-10 top-8 select-none text-[280px] font-black text-black/[0.055]"
              style={{ y: wmY }}
            >
              ☥
            </motion.div>

            <div className="relative grid gap-10 p-10 md:grid-cols-[1.15fr_0.85fr] md:p-14">
              {/* COPY */}
              <div className="space-y-7">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="chip">THE YARD</span>
                  <span className="chip">Members-only signal</span>
                  <span className="chip">Drops • Notes • Updates</span>
                </div>

                <h1 className="title-display text-5xl font-black text-black md:text-7xl">
                  The Yard is a doorway.
                  <span className="block text-black/80">Not a feed. Not noise.</span>
                  <span className="block underline decoration-black/15 underline-offset-8">
                    First access.
                  </span>
                </h1>

                <p className="max-w-xl text-lg font-semibold muted">
                  Pick a house. Generate your Yard Pass. Unlock private updates.
                  <span className="font-black text-black"> Your ID is your entry.</span>
                </p>

                <div className="flex flex-wrap gap-3">
                  <MagneticLink href="#pass" className="btn-ink">
                    <span className="relative z-10">Generate Yard Pass ☥</span>
                    <span aria-hidden className="btn-shine" />
                  </MagneticLink>

                  <MagneticLink href="/profile" className="btn-ghost">
                    I already have an ID
                  </MagneticLink>
                </div>

                <div className="grid gap-4 pt-2 sm:grid-cols-3">
                  <Stat k="ACCESS" v="PRIVATE" />
                  <Stat k="HOUSE" v="CHOSEN" />
                  <Stat k="PASS" v="GENERATED" />
                </div>
              </div>

              {/* VISUALS */}
              <motion.div style={{ y: galleryY }} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <Poster src={posters[0].src} label={posters[0].label} priority />
                  <Poster src={posters[1].src} label={posters[1].label} />
                  <Poster src={posters[2].src} label={posters[2].label} />
                  <div className="col-span-2">
                    <Poster src={posters[3].src} label={posters[3].label} wide />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Caption>{posters[0].label}</Caption>
                  <Caption>{posters[1].label}</Caption>
                  <Caption>{posters[2].label}</Caption>
                  <div className="col-span-2">
                    <Caption>{posters[3].label}</Caption>
                  </div>
                </div>

                <div className="ink-card relative overflow-hidden p-6 lift border-shimmer">
                  <div className="absolute -right-10 -top-10 text-[180px] font-black text-[rgb(var(--yard-yellow))]/10">
                    ☥
                  </div>

                  <div className="relative flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-80">
                        Yard Pass (Preview)
                      </p>
                      <h3 className="mt-2 text-xl font-black">Members-only access.</h3>
                      <p className="mt-1 text-sm font-semibold opacity-80">
                        Generate your ID below and download your card.
                      </p>
                    </div>

                    <div className="rounded-2xl bg-[rgb(var(--yard-yellow))] px-4 py-3 text-black shadow-[0_18px_50px_rgba(0,0,0,0.2)]">
                      <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-70">
                        Status
                      </p>
                      <p className="text-sm font-black">ACTIVE</p>
                    </div>
                  </div>

                  <div className="relative mt-5 rounded-2xl border border-[rgb(var(--yard-yellow))]/25 bg-black/40 px-4 py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black opacity-80">ID</span>
                      <span className="font-mono text-xs font-black tracking-wider">
                        YARD-25-XXXXXXXX
                      </span>
                    </div>

                    <div className="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-[rgb(var(--yard-yellow))]/10">
                      <motion.div
                        className="h-2 rounded-full bg-[rgb(var(--yard-yellow))]/40"
                        initial={prefersReduced ? undefined : { width: "18%" }}
                        animate={prefersReduced ? undefined : { width: "66%" }}
                        transition={{ duration: 1.1, ease: "easeOut" }}
                      />
                      <div className="shimmer absolute inset-0 opacity-20 mask-fade" />
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </section>
        </div>

        {/* INTRO OVERLAY (yards.jpg + white copy + nav) */}
        <div
          ref={(n) => {
            overlayRef.current = n;
          }}
          className="introOverlay absolute inset-0"
        >
          <div
            ref={(n) => {
              overlayImgRef.current = n;
            }}
            className="absolute inset-0"
          >
            <Image
              src="/Pictures/yard.jpg"
              alt="The Yard"
              fill
              priority
              sizes="100vw"
              className="object-cover"
              onLoadingComplete={refreshST}
            />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.08),transparent_45%)]" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/45 to-black/75" />
            <div className="absolute inset-0 vignette-dark" />
            <div className="absolute inset-0 grain opacity-[0.20]" />
          </div>

          {/* Dark nav (white) */}
          <div ref={navDarkRef} className="absolute left-0 right-0 top-0 z-20">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 md:px-10">
              <Link href="/" className="flex items-center gap-3">
                <span className="text-2xl font-black text-white">☥</span>
                <span className="text-sm font-black tracking-[0.22em] text-white/90">
                  THE YARD
                </span>
              </Link>

              <div className="hidden items-center gap-7 md:flex">
                <a href="#houses" className="navLinkWhite">
                  Houses
                </a>
                <a href="#feed" className="navLinkWhite">
                  Feed
                </a>
                <a href="#pass" className="navLinkWhite">
                  Yard Pass
                </a>
                <Link href="/profile" className="navBtnWhite">
                  Sign in
                </Link>
              </div>
            </div>
          </div>

          {/* Light nav (black) — fades in after reveal */}
          <div ref={navLightRef} className="absolute left-0 right-0 top-0 z-20">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 md:px-10">
              <Link href="/" className="flex items-center gap-3">
                <span className="text-2xl font-black text-black">☥</span>
                <span className="text-sm font-black tracking-[0.22em] text-black/80">
                  THE YARD
                </span>
              </Link>

              <div className="hidden items-center gap-7 md:flex">
                <a href="#houses" className="navLinkBlack">
                  Houses
                </a>
                <a href="#feed" className="navLinkBlack">
                  Feed
                </a>
                <a href="#pass" className="navLinkBlack">
                  Yard Pass
                </a>
                <Link href="/profile" className="navBtnBlack">
                  Sign in
                </Link>
              </div>
            </div>
          </div>

          {/* FULL-SCREEN PHOTO COPY (new “cool stuff”) */}
          <div className="relative z-10 mx-auto flex h-full max-w-6xl flex-col justify-end px-6 pb-12 md:px-10 md:pb-16">
            <div className="grid gap-10 md:grid-cols-[1.15fr_0.85fr] md:items-end">
              {/* Left: hero text */}
              <div className="max-w-2xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="chipDark">Members-only</span>
                  <span className="chipDark">No noise</span>
                  <span className="chipDark">First access</span>
                </div>

                <p className="mt-6 text-xs font-black tracking-[0.24em] text-white/70 uppercase">
                  Get your ID ready • This is the entrance sequence
                </p>

                <h1 className="mt-4 text-5xl font-black leading-[0.95] text-white md:text-7xl">
                  Enter The Yard.
                </h1>

                <p className="mt-4 max-w-xl text-base font-semibold text-white/85 md:text-lg">
                  Your pass is your proof. Choose a house. Generate your ID. Then you can see the
                  updates.
                  <span className="font-black text-white"> No pass, no feed.</span>
                </p>

                <div className="mt-6 flex flex-wrap gap-3">
                  <a href="#pass" className="ctaWhite">
                    Generate my Yard Pass ☥
                  </a>
                  <a href="#houses" className="ctaGhostWhite">
                    Choose a house
                  </a>
                </div>

                <div className="mt-6 flex flex-wrap gap-2 md:hidden">
                  <span className="chipDark">ID → Entry</span>
                  <span className="chipDark">House → Stamp</span>
                  <span className="chipDark">Scroll → Reveal</span>
                </div>

                <p className="mt-5 text-xs font-black tracking-[0.22em] text-white/60 uppercase">
                  Scroll to reveal
                </p>
              </div>

              {/* Right: checklist card */}
              <div className="hidden md:block">
                <div className="rounded-[28px] border border-white/16 bg-white/6 p-6 backdrop-blur-[10px] shadow-[0_26px_90px_rgba(0,0,0,0.25)]">
                  <p className="text-[11px] font-extrabold uppercase tracking-[0.24em] text-white/70">
                    Entry Checklist
                  </p>

                  <ul className="mt-4 space-y-3 text-sm font-semibold text-white/85">
                    <li className="flex items-start gap-3">
                      <span className="mt-2 h-2 w-2 rounded-full bg-white/50" />
                      <span>
                        <span className="font-black text-white">Get your ID ready</span> — your pass
                        is your entry.
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="mt-2 h-2 w-2 rounded-full bg-white/50" />
                      <span>
                        <span className="font-black text-white">Pick a house</span> — Descendant or
                        Angel.
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="mt-2 h-2 w-2 rounded-full bg-white/50" />
                      <span>
                        <span className="font-black text-white">Generate your Yard Pass</span> —
                        download it.
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="mt-2 h-2 w-2 rounded-full bg-white/50" />
                      <span>
                        <span className="font-black text-white">Sign in</span> — unlock the
                        members-only feed.
                      </span>
                    </li>
                  </ul>

                  <div className="mt-5 rounded-2xl border border-white/12 bg-black/25 px-4 py-3">
                    <p className="text-xs font-black tracking-[0.20em] text-white/70 uppercase">
                      Tip
                    </p>
                    <p className="mt-1 text-sm font-semibold text-white/80">
                      Use a clean portrait photo. The card looks crazy when it’s HD.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Houses */}
      <section id="houses" className="grid gap-5 md:grid-cols-2">
        <House
          title="♂ Descendants"
          badge="DESCENDANTS"
          desc="Legacy energy. Grounded. Loyal. Builders of The Yard."
        />
        <House
          title="♀ Angels 🪽"
          badge="ANGELS"
          desc="Light energy. Elevation. Grace. Aura of The Yard."
        />
      </section>

      {/* Locked feed */}
      <section id="feed" className="paper-card relative overflow-hidden p-10">
        <div className="absolute inset-0 ankh-wall opacity-[0.55]" />
        <div className="absolute inset-0 microgrid opacity-[0.18]" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-transparent to-black/10" />
        <div className="absolute inset-0 vignette-soft" />
        <div className="absolute inset-0 grain opacity-[0.16]" />

        <div className="relative flex flex-wrap items-start justify-between gap-6">
          <div className="max-w-2xl">
            <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/60">
              Updates Feed
            </p>
            <h2 className="mt-2 text-4xl font-black text-black">Members-only updates.</h2>
            <p className="mt-2 text-base font-semibold muted">
              Tour announcements, unreleased previews, drop alerts, private notes —
              locked behind your Yard Pass.
            </p>
          </div>

          <motion.div
            whileHover={prefersReduced ? undefined : { y: -2, scale: 1.01 }}
            className="ink-card px-5 py-4 border-shimmer"
          >
            <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-80">
              🔒 Locked
            </p>
            <p className="text-sm font-black">Sign in to view</p>
          </motion.div>
        </div>

        <div className="relative mt-7 grid gap-4 md:grid-cols-3">
          <FeedCard title="Tour update" />
          <FeedCard title="Drop alert" />
          <FeedCard title="Private note" />
        </div>

        <div className="relative mt-7 flex flex-wrap gap-3">
          <MagneticLink href="#pass" className="btn-ink">
            <span className="relative z-10">Create my Yard Pass</span>
            <span aria-hidden className="btn-shine" />
          </MagneticLink>
          <MagneticLink href="/profile" className="btn-ghost">
            Sign in with my ID
          </MagneticLink>
        </div>
      </section>

      {/* ========================= */}
      {/* YARD PASS GENERATOR (FORM) */}
      {/* ========================= */}
      <section id="pass" className="ink-card relative overflow-hidden p-10 border-shimmer">
        <div className="absolute inset-0 opacity-15">
          <AnkhPattern />
        </div>
        <div className="absolute inset-0 vignette-soft" />
        <div className="absolute inset-0 grain opacity-[0.14]" />

        <div className="relative grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="space-y-3">
            <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-80">
              Yard Pass Generator
            </p>
            <h3 className="text-4xl font-black">Generate your card.</h3>
            <p className="text-sm font-semibold opacity-80">
              Fill your details, pick your house, upload a photo — and download your pass.
            </p>

            <div className="mt-6">
              <PassGenerator />
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-3xl border border-white/10 bg-black/40 p-6">
              <p className="text-xs font-black tracking-[0.22em] uppercase opacity-70">
                What this feels like
              </p>
              <p className="mt-3 text-sm font-semibold opacity-85">
                A real ID. A real entrance. You’re not “subscribing” — you’re entering a house.
              </p>
              <div className="mt-5 grid grid-cols-3 gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.22em] opacity-70">
                    HOUSE
                  </p>
                  <p className="mt-1 text-sm font-black">Auto</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.22em] opacity-70">
                    CARD
                  </p>
                  <p className="mt-1 text-sm font-black">HD PNG</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                  <p className="text-[10px] font-black uppercase tracking-[0.22em] opacity-70">
                    ID
                  </p>
                  <p className="mt-1 text-sm font-black">Unique</p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-black/40 p-6">
              <p className="text-xs font-black tracking-[0.22em] uppercase opacity-70">
                Rules of The Yard
              </p>
              <ul className="mt-3 space-y-2 text-sm font-semibold opacity-85">
                <li>• No noise. Only signal.</li>
                <li>• Access is personal — your pass is your entry.</li>
                <li>• Your house isn’t a vibe — it’s a stamp.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Outro CTA */}
      <section className="paper-card relative overflow-hidden p-10">
        <div className="absolute inset-0 microgrid opacity-[0.18]" />
        <div className="absolute inset-0 vignette-soft" />
        <div className="absolute inset-0 grain opacity-[0.12]" />

        <div className="relative flex flex-wrap items-center justify-between gap-6">
          <div>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/60">
              The Yard
            </p>
            <h3 className="mt-2 text-4xl font-black text-black">You’re early.</h3>
            <p className="mt-2 text-sm font-semibold muted">
              Generate your pass — then sign in anytime.
            </p>
          </div>

          <a
            href="#pass"
            className="rounded-full bg-[rgb(var(--yard-yellow))] px-8 py-4 text-sm font-black text-black hover:opacity-90 shadow-[0_22px_70px_rgba(0,0,0,0.25)]"
          >
            Generate Yard Pass ☥
          </a>
        </div>
      </section>

      <style jsx global>{`
        :root { --yard-yellow: 253 208 0; }

        .muted { color: rgba(0, 0, 0, 0.72); }
        .title-display { letter-spacing: -0.02em; }

        /* Ensure the pinned intro is true full-viewport */
        .introPin { min-height: 100vh; min-height: 100svh; background: rgba(255, 210, 0, 0.10); }
        .introOverlay { will-change: opacity; }

        .navLinkWhite, .navLinkBlack {
          font-weight: 900;
          font-size: 12px;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          transition: opacity 180ms ease, transform 180ms ease;
        }
        .navLinkWhite { color: rgba(255,255,255,0.86); }
        .navLinkWhite:hover { opacity: 1; transform: translateY(-1px); color: #fff; }
        .navLinkBlack { color: rgba(0,0,0,0.72); }
        .navLinkBlack:hover { opacity: 1; transform: translateY(-1px); color: rgba(0,0,0,0.92); }

        .navBtnWhite, .navBtnBlack {
          border-radius: 999px;
          padding: 10px 14px;
          font-size: 12px;
          font-weight: 900;
          letter-spacing: 0.16em;
          text-transform: uppercase;
        }
        .navBtnWhite { color: #000; background: rgba(255,255,255,0.92); }
        .navBtnBlack {
          color: rgba(0,0,0,0.92);
          background: rgba(255,255,255,0.60);
          border: 1px solid rgba(0,0,0,0.10);
          backdrop-filter: blur(10px);
        }

        .ctaWhite {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border-radius: 999px;
          padding: 14px 18px;
          font-size: 13px;
          font-weight: 900;
          color: #000;
          background: rgb(var(--yard-yellow));
          box-shadow: 0 22px 70px rgba(0,0,0,0.25);
        }
        .ctaWhite:hover { opacity: 0.94; }

        .ctaGhostWhite {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border-radius: 999px;
          padding: 14px 18px;
          font-size: 13px;
          font-weight: 900;
          color: rgba(255,255,255,0.88);
          background: rgba(255,255,255,0.10);
          border: 1px solid rgba(255,255,255,0.18);
          backdrop-filter: blur(10px);
        }
        .ctaGhostWhite:hover { background: rgba(255,255,255,0.14); }

        .heroStage { isolation: isolate; }

        .microgrid {
          background-image: radial-gradient(circle at 1px 1px, rgba(0, 0, 0, 0.06) 1px, transparent 0);
          background-size: 22px 22px;
          mask-image: radial-gradient(circle at 50% 30%, rgba(0, 0, 0, 1), transparent 65%);
        }

        .vignette { background: radial-gradient(1200px 740px at 50% 28%, transparent 35%, rgba(0, 0, 0, 0.11) 76%); mix-blend-mode: multiply; }
        .vignette-soft { background: radial-gradient(900px 560px at 50% 35%, transparent 40%, rgba(0, 0, 0, 0.085) 86%); mix-blend-mode: multiply; }
        .vignette-dark { background: radial-gradient(1200px 740px at 50% 30%, transparent 25%, rgba(0, 0, 0, 0.55) 78%); mix-blend-mode: multiply; }

        .grain {
          pointer-events: none;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='.35'/%3E%3C/svg%3E");
          mix-blend-mode: soft-light;
        }

        .chipDark {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          border-radius: 999px;
          padding: 8px 12px;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.22em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.80);
          background: rgba(255,255,255,0.10);
          border: 1px solid rgba(255,255,255,0.16);
          backdrop-filter: blur(10px);
        }

        .btn-shine {
          position: absolute;
          inset: -2px;
          background: radial-gradient(680px 140px at var(--sx, 50%) 0%, rgba(255, 210, 0, 0.26), transparent 55%);
          opacity: 0.9;
          mix-blend-mode: screen;
          pointer-events: none;
        }

        .border-shimmer { position: relative; }
        .border-shimmer:before {
          content: "";
          position: absolute;
          inset: -1px;
          border-radius: inherit;
          padding: 1px;
          background: conic-gradient(
            from 180deg,
            rgba(255, 210, 0, 0),
            rgba(255, 210, 0, 0.35),
            rgba(255, 210, 0, 0),
            rgba(255, 210, 0, 0.22),
            rgba(255, 210, 0, 0)
          );
          -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
          opacity: 0.65;
          pointer-events: none;
          animation: spin 7s linear infinite;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        .shimmer {
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.55), transparent);
          transform: translateX(-60%);
          animation: shimmer 1.8s infinite;
        }
        @keyframes shimmer { 0% { transform: translateX(-60%); } 100% { transform: translateX(60%); } }

        .mask-fade { mask-image: radial-gradient(circle at 50% 50%, rgba(0, 0, 0, 0.9), transparent 70%); }

        .caption {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 4px 0;
          color: rgba(0, 0, 0, 0.62);
          font-size: 11px;
          font-weight: 900;
          letter-spacing: 0.22em;
          text-transform: uppercase;
        }
        .captionDot { width: 8px; height: 8px; border-radius: 999px; background: rgba(0, 0, 0, 0.18); }
      `}</style>
    </div>
  );
}

/* ===================== */
/* PASS GENERATOR (CANVAS) */
/* ===================== */

function PassGenerator() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [gender, setGender] = useState<Gender>("");
  const [photoDataUrl, setPhotoDataUrl] = useState<string | undefined>(undefined);

  const [card, setCard] = useState<PassCard | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [saving, setSaving] = useState(false);

  // Load saved card (optional convenience)
  useEffect(() => {
    try {
      const raw = localStorage.getItem("yard_pass_card_v1");
      if (!raw) return;
      const parsed = JSON.parse(raw) as PassCard;
      setCard(parsed);
    } catch {}
  }, []);

  useEffect(() => {
    if (!card || !canvasRef.current) return;
    drawPass(canvasRef.current, card);
  }, [card]);

  const onPickPhoto = async (file?: File | null) => {
    if (!file) return setPhotoDataUrl(undefined);
    const reader = new FileReader();
    reader.onload = () => setPhotoDataUrl(String(reader.result || ""));
    reader.readAsDataURL(file);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !phone.trim() || !gender) return;

    const id = `YARD-${new Date().getFullYear().toString().slice(-2)}-${Math.random()
      .toString(36)
      .slice(2, 10)
      .toUpperCase()}`;

    const houseLabel = gender === "male" ? "Descendant" : "Angel";
    const createdAt = new Date().toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

    setCard({
      id,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      houseLabel,
      createdAt,
      photoDataUrl,
    });
  };

  const downloadPNG = async () => {
    if (!canvasRef.current) return;
    setSaving(true);
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!blob) return;

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = (card?.id || "yard-pass") + ".png";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setSaving(false);
    }
  };

  const saveToBrowser = () => {
    if (!card) return;
    try {
      localStorage.setItem("yard_pass_card_v1", JSON.stringify(card));
    } catch {}
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Form */}
      <form onSubmit={submit} className="rounded-3xl border border-white/10 bg-black/40 p-6">
        <div className="grid gap-4">
          <Field label="Full name">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="field"
              placeholder="Your name"
              required
            />
          </Field>

          <Field label="Email">
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="field"
              placeholder="you@email.com"
              type="email"
              required
            />
          </Field>

          <Field label="Phone number">
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="field"
              placeholder="+234..."
              required
            />
          </Field>

          <Field label="Gender">
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setGender("male")}
                className={`pill ${gender === "male" ? "pillOn" : ""}`}
              >
                Male → Descendant
              </button>
              <button
                type="button"
                onClick={() => setGender("female")}
                className={`pill ${gender === "female" ? "pillOn" : ""}`}
              >
                Female → Angel
              </button>
            </div>
          </Field>

          <Field label="Upload photo">
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onPickPhoto(e.target.files?.[0])}
              className="file"
            />
            <p className="mt-2 text-xs font-semibold opacity-70">
              Tip: use a portrait photo for best results.
            </p>
          </Field>

          <button
            className="rounded-full bg-[rgb(var(--yard-yellow))] px-5 py-3 text-sm font-black text-black hover:opacity-90"
            type="submit"
          >
            Generate my card ☥
          </button>

          <style jsx>{`
            .field {
              width: 100%;
              border-radius: 16px;
              padding: 12px 14px;
              font-weight: 800;
              font-size: 13px;
              background: rgba(255,255,255,0.06);
              border: 1px solid rgba(255,255,255,0.10);
              color: rgba(255,255,255,0.92);
              outline: none;
            }
            .field::placeholder { color: rgba(255,255,255,0.45); }
            .field:focus {
              border-color: rgba(253,208,0,0.35);
              box-shadow: 0 0 0 4px rgba(253,208,0,0.10);
            }

            .pill {
              border-radius: 18px;
              padding: 12px 14px;
              font-weight: 900;
              font-size: 12px;
              letter-spacing: 0.10em;
              text-transform: uppercase;
              background: rgba(255,255,255,0.06);
              border: 1px solid rgba(255,255,255,0.10);
              color: rgba(255,255,255,0.86);
              transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
            }
            .pill:hover { transform: translateY(-1px); background: rgba(255,255,255,0.08); }
            .pillOn {
              background: rgba(253,208,0,0.14);
              border-color: rgba(253,208,0,0.32);
              color: rgba(255,255,255,0.96);
            }

            .file {
              width: 100%;
              border-radius: 16px;
              padding: 10px 12px;
              font-weight: 800;
              font-size: 12px;
              background: rgba(255,255,255,0.06);
              border: 1px solid rgba(255,255,255,0.10);
              color: rgba(255,255,255,0.82);
            }
          `}</style>
        </div>
      </form>

      {/* Preview + actions */}
      <div className="rounded-3xl border border-white/10 bg-black/40 p-6">
        <p className="text-xs font-black tracking-[0.22em] uppercase opacity-70">
          Your generated card
        </p>

        <div className="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-black/50">
          <canvas ref={canvasRef} className="w-full h-auto block" />
        </div>

        <div className="mt-4 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={downloadPNG}
            disabled={!card || saving}
            className="rounded-full bg-[rgb(var(--yard-yellow))] px-5 py-3 text-sm font-black text-black disabled:opacity-40"
          >
            {saving ? "Preparing..." : "Download PNG"}
          </button>

          <button
            type="button"
            onClick={saveToBrowser}
            disabled={!card}
            className="rounded-full bg-white/10 px-5 py-3 text-sm font-black text-white disabled:opacity-40 border border-white/10 hover:bg-white/12"
          >
            Save to browser
          </button>
        </div>

        <p className="mt-3 text-xs font-semibold opacity-70">
          Male → <span className="font-black">Descendant</span> • Female →{" "}
          <span className="font-black">Angel</span>
        </p>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-75">
        {label}
      </p>
      <div className="mt-2">{children}</div>
    </div>
  );
}

async function drawPass(canvas: HTMLCanvasElement, card: PassCard) {
  // High-res export
  const W = 1080;
  const H = 1350;

  const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.aspectRatio = `${W}/${H}`;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  // Background
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#07090C");
  bg.addColorStop(0.55, "#0B0F14");
  bg.addColorStop(1, "#06070A");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Accent glow
  const glow = ctx.createRadialGradient(W * 0.72, H * 0.18, 10, W * 0.72, H * 0.18, 520);
  glow.addColorStop(0, "rgba(253,208,0,0.28)");
  glow.addColorStop(0.45, "rgba(253,208,0,0.10)");
  glow.addColorStop(1, "rgba(253,208,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // Watermark ankh
  ctx.globalAlpha = 0.10;
  ctx.fillStyle = "rgba(253,208,0,1)";
  ctx.font = "900 420px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("☥", -70, 520);
  ctx.globalAlpha = 1;

  // Card frame
  roundedRect(ctx, 70, 80, W - 140, H - 160, 48);
  ctx.fillStyle = "rgba(255,255,255,0.06)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Header
  ctx.fillStyle = "rgba(255,255,255,0.86)";
  ctx.font = "900 26px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("THE YARD", 120, 165);

  ctx.fillStyle = "rgba(255,255,255,0.60)";
  ctx.font = "800 14px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("YARD PASS • MEMBERS ONLY", 120, 195);

  // House chip
  const chipText = card.houseLabel.toUpperCase();
  const chipW = Math.max(260, ctx.measureText(chipText).width + 80);
  roundedRect(ctx, W - 120 - chipW, 135, chipW, 54, 28);
  ctx.fillStyle = "rgba(253,208,0,0.18)";
  ctx.fill();
  ctx.strokeStyle = "rgba(253,208,0,0.35)";
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.font = "900 14px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText(chipText, W - 120 - chipW + 32, 168);

  // Photo block
  const px = 120;
  const py = 245;
  const pw = W - 240;
  const ph = 700;

  roundedRect(ctx, px, py, pw, ph, 42);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.stroke();

  if (card.photoDataUrl) {
    const img = await loadImage(card.photoDataUrl);
    // cover fit
    const scale = Math.max(pw / img.width, ph / img.height);
    const iw = img.width * scale;
    const ih = img.height * scale;
    const ix = px + (pw - iw) / 2;
    const iy = py + (ph - ih) / 2;

    ctx.save();
    roundedRect(ctx, px, py, pw, ph, 42);
    ctx.clip();
    ctx.drawImage(img, ix, iy, iw, ih);
    ctx.restore();

    // glaze
    const glaze = ctx.createLinearGradient(0, py, 0, py + ph);
    glaze.addColorStop(0, "rgba(0,0,0,0.10)");
    glaze.addColorStop(0.65, "rgba(0,0,0,0.00)");
    glaze.addColorStop(1, "rgba(0,0,0,0.40)");
    ctx.fillStyle = glaze;
    roundedRect(ctx, px, py, pw, ph, 42);
    ctx.fill();
  } else {
    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.font = "900 22px system-ui, -apple-system, Segoe UI, Roboto";
    ctx.fillText("Upload a photo for the full look.", px + 40, py + 70);
  }

  // Name
  ctx.fillStyle = "rgba(255,255,255,0.96)";
  ctx.font = "900 56px system-ui, -apple-system, Segoe UI, Roboto";
  wrapText(ctx, card.name.toUpperCase(), 120, 1035, W - 240, 62);

  // Details
  ctx.fillStyle = "rgba(255,255,255,0.72)";
  ctx.font = "800 20px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText(card.email, 120, 1132);
  ctx.fillText(card.phone, 120, 1166);

  // Footer ID
  roundedRect(ctx, 120, 1200, W - 240, 92, 28);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fill();
  ctx.strokeStyle = "rgba(253,208,0,0.28)";
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.78)";
  ctx.font = "900 14px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas";
  ctx.fillText(`ID: ${card.id}`, 150, 1240);

  ctx.fillStyle = "rgba(255,255,255,0.55)";
  ctx.font = "800 14px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText(
    `Issued: ${card.createdAt}`,
    W - 150 - ctx.measureText(`Issued: ${card.createdAt}`).width,
    1240
  );

  // Small mark
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = "rgba(253,208,0,1)";
  ctx.font = "900 140px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("☥", W - 240, H - 120);
  ctx.globalAlpha = 1;
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxW: number,
  lineH: number
) {
  const words = text.split(" ");
  let line = "";
  let yy = y;

  for (let i = 0; i < words.length; i++) {
    const test = line ? `${line} ${words[i]}` : words[i];
    const w = ctx.measureText(test).width;
    if (w > maxW && line) {
      ctx.fillText(line, x, yy);
      line = words[i];
      yy += lineH;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new window.Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

/* ---------- components (your existing ones) ---------- */

function Caption({ children }: { children: React.ReactNode }) {
  return (
    <div className="caption">
      <span className="captionDot" />
      <span className="truncate">{children}</span>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      transition={{ duration: 0.18 }}
      className="yard-frame corner-stamps p-5 lift"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(0,0,0,0.05),transparent_40%)]" />
      <div className="absolute inset-0 grain opacity-[0.10]" />
      <div className="relative">
        <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/55">{k}</p>
        <p className="mt-1 text-2xl font-black text-black">{v}</p>
        <div className="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-black/10">
          <motion.div
            className="h-2 w-2/3 rounded-full bg-black/20"
            whileHover={{ x: 6 }}
            transition={{ type: "spring", stiffness: 220, damping: 20 }}
          />
          <div className="shimmer absolute inset-0 opacity-15 mask-fade" />
        </div>
      </div>
    </motion.div>
  );
}

function Poster({
  src,
  label,
  wide,
  priority,
}: {
  src: string;
  label: string;
  wide?: boolean;
  priority?: boolean;
}) {
  return (
    <TiltCard
      className={[
        "group yard-frame corner-stamps lift border-shimmer",
        wide ? "h-56 md:h-64" : "h-44 md:h-48",
      ].join(" ")}
    >
      <div className="absolute inset-0">
        <Image
          src={src}
          alt={label}
          fill
          priority={priority}
          sizes={wide ? "(min-width: 768px) 520px, 100vw" : "(min-width: 768px) 260px, 50vw"}
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
        />
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/35" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.30),transparent_42%)] mix-blend-overlay" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_85%,rgba(255,210,0,0.18),transparent_55%)] mix-blend-multiply" />
      <div className="absolute inset-0 grain opacity-[0.18]" />

      <div className="pointer-events-none absolute right-4 top-4 text-3xl font-black text-white/20 drop-shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
        ☥
      </div>

      <div className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute inset-0 bg-[linear-gradient(115deg,transparent,rgba(255,255,255,0.20),transparent)] translate-x-[-60%] group-hover:translate-x-[60%] transition-transform duration-700 ease-out" />
      </div>
    </TiltCard>
  );
}

function House({ title, badge, desc }: { title: string; badge: string; desc: string }) {
  return (
    <TiltCard className="ink-card relative overflow-hidden p-8 lift border-shimmer">
      <div className="absolute -right-10 -top-10 text-[200px] font-black text-[rgb(var(--yard-yellow))]/10">
        ☥
      </div>
      <div className="absolute inset-0 grain opacity-[0.10]" />

      <div className="relative flex items-start justify-between gap-4">
        <div>
          <p className="text-xl font-black">{title}</p>
          <p className="mt-3 text-sm font-semibold opacity-80">{desc}</p>
        </div>

        <span className="rounded-2xl bg-[rgb(var(--yard-yellow))] px-4 py-2 text-xs font-black text-black shadow-[0_18px_50px_rgba(0,0,0,0.18)]">
          {badge}
        </span>
      </div>

      <div className="relative mt-6 rounded-2xl border border-[rgb(var(--yard-yellow))]/20 bg-black/40 px-4 py-3">
        <div className="flex items-center justify-between text-xs font-black opacity-85">
          <span>Access</span>
          <span>Members-only</span>
        </div>
      </div>
    </TiltCard>
  );
}

function FeedCard({ title }: { title: string }) {
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      transition={{ duration: 0.18 }}
      className="yard-frame p-6 lift"
    >
      <div className="absolute inset-0 backdrop-blur-[8px]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(0,0,0,0.06),transparent_40%)]" />
      <div className="absolute inset-0 grain opacity-[0.10]" />

      <div className="relative space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-sm font-black text-black">{title}</p>
          <span className="rounded-full bg-black px-3 py-1 text-xs font-black text-[rgb(var(--yard-yellow))]">
            🔒
          </span>
        </div>

        <div className="space-y-2">
          <div className="h-2 w-5/6 rounded-full bg-black/15" />
          <div className="h-2 w-4/6 rounded-full bg-black/10" />
          <div className="h-2 w-3/6 rounded-full bg-black/10" />
        </div>

        <p className="pt-1 text-xs font-bold text-black/60">Sign in to view this update.</p>
      </div>

      <div className="shimmer absolute inset-0 opacity-[0.08] mask-fade" />
    </motion.div>
  );
}

function AnkhPattern() {
  return (
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="ankh" x="0" y="0" width="140" height="140" patternUnits="userSpaceOnUse">
          <text x="18" y="88" fontSize="64" fontWeight="900" fill="rgba(255,210,0,0.25)">
            ☥
          </text>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#ankh)" />
    </svg>
  );
}

/* ---------- motion helpers ---------- */

function MagneticLink({
  href,
  className,
  children,
}: {
  href: string;
  className: string;
  children: React.ReactNode;
}) {
  const prefersReduced = useReducedMotion();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 260, damping: 22, mass: 0.35 });
  const sy = useSpring(y, { stiffness: 260, damping: 22, mass: 0.35 });

  return (
    <motion.div
      style={prefersReduced ? undefined : { x: sx, y: sy }}
      onMouseMove={(e) => {
        if (prefersReduced) return;
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2);
        const dy = e.clientY - (r.top + r.height / 2);
        x.set(dx * 0.12);
        y.set(dy * 0.12);

        const pct = Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100));
        (e.currentTarget as HTMLElement).style.setProperty("--sx", `${pct}%`);
      }}
      onMouseLeave={(e) => {
        x.set(0);
        y.set(0);
        (e.currentTarget as HTMLElement).style.setProperty("--sx", `50%`);
      }}
      className="inline-flex"
    >
      <Link href={href} className={className}>
        {children}
      </Link>
    </motion.div>
  );
}

function TiltCard({ className, children }: { className: string; children: React.ReactNode }) {
  const prefersReduced = useReducedMotion();
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 220, damping: 22, mass: 0.35 });
  const sry = useSpring(ry, { stiffness: 220, damping: 22, mass: 0.35 });

  return (
    <motion.div
      className={className}
      style={
        prefersReduced
          ? undefined
          : {
              transformStyle: "preserve-3d",
              rotateX: srx,
              rotateY: sry,
            }
      }
      onMouseMove={(e) => {
        if (prefersReduced) return;
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        ry.set((px - 0.5) * 10);
        rx.set(-(py - 0.5) * 8);
      }}
      onMouseLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
    >
      <div
        className="relative h-full w-full"
        style={prefersReduced ? undefined : ({ transform: "translateZ(18px)" } as any)}
      >
        {children}
      </div>
    </motion.div>
  );
}
