// app/admin/passes/page.tsx
import AdminPage from "./AdminPage.client";

export default function Page() {
  return <AdminPage />;
}
