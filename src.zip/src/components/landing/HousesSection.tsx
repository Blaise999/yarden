"use client";

import React from "react";
import { HouseCard } from "@/components/landing/atoms";

export default function HousesSection() {
  return (
    <section id="houses" className="grid gap-5 md:grid-cols-2">
      <HouseCard
        title="♂ Descendants"
        badge="DESCENDANTS"
        desc="Legacy energy. Grounded. Loyal. Builders of The Yard."
      />
      <HouseCard
        title="♀ Angels 🪽"
        badge="ANGELS"
        desc="Light energy. Elevation. Grace. Aura of The Yard."
      />
    </section>
  );
}
