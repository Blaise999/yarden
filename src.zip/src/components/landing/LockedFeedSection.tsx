"use client";

import React from "react";
import { FeedCard, MagneticLink } from "@/components/landing/atoms";

export default function LockedFeedSection() {
  return (
    <section id="feed" className="paper-card relative overflow-hidden p-10">
      <div className="absolute inset-0 ankh-wall opacity-[0.55]" />
      <div className="absolute inset-0 microgrid opacity-[0.18]" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-transparent to-black/10" />
      <div className="absolute inset-0 vignette-soft" />
      <div className="absolute inset-0 grain opacity-[0.16]" />

      <div className="relative flex flex-wrap items-start justify-between gap-6">
        <div className="max-w-2xl">
          <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/60">
            Updates Feed
          </p>
          <h2 className="mt-2 text-4xl font-black text-black">Members-only updates.</h2>
          <p className="mt-2 text-base font-semibold muted">
            Tour announcements, unreleased previews, drop alerts, private notes — locked behind your Yard Pass.
          </p>
        </div>

        <div className="ink-card px-5 py-4 border-shimmer">
          <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-80">
            🔒 Locked
          </p>
          <p className="text-sm font-black">Sign in to view</p>
        </div>
      </div>

      <div className="relative mt-7 grid gap-4 md:grid-cols-3">
        <FeedCard title="Tour update" />
        <FeedCard title="Drop alert" />
        <FeedCard title="Private note" />
      </div>

      <div className="relative mt-7 flex flex-wrap gap-3">
        <MagneticLink href="#pass" className="btn-ink">
          <span className="relative z-10">Create my Yard Pass</span>
          <span aria-hidden className="btn-shine" />
        </MagneticLink>
        <MagneticLink href="/profile" className="btn-ghost">
          Sign in with my ID
        </MagneticLink>
      </div>
    </section>
  );
}
