"use client";

import React, { useEffect, useRef, useState } from "react";

type Gender = "male" | "female" | "";

export type PassCard = {
  id: string;
  name: string;
  email: string;
  phone: string;
  houseLabel: "Descendant" | "Angel";
  createdAt: string;
  photoDataUrl?: string;
};

export default function PassGenerator() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [gender, setGender] = useState<Gender>("");
  const [photoDataUrl, setPhotoDataUrl] = useState<string | undefined>(undefined);

  const [card, setCard] = useState<PassCard | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [saving, setSaving] = useState(false);

  // Load saved card (optional convenience)
  useEffect(() => {
    try {
      const raw = localStorage.getItem("yard_pass_card_v1");
      if (!raw) return;
      const parsed = JSON.parse(raw) as PassCard;
      setCard(parsed);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!card || !canvasRef.current) return;
    drawPass(canvasRef.current, card);
  }, [card]);

  const onPickPhoto = async (file?: File | null) => {
    if (!file) return setPhotoDataUrl(undefined);
    const reader = new FileReader();
    reader.onload = () => setPhotoDataUrl(String(reader.result || ""));
    reader.readAsDataURL(file);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !phone.trim() || !gender) return;

    const id = `YARD-${new Date().getFullYear().toString().slice(-2)}-${Math.random()
      .toString(36)
      .slice(2, 10)
      .toUpperCase()}`;

    const houseLabel = gender === "male" ? "Descendant" : "Angel";
    const createdAt = new Date().toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

    setCard({
      id,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      houseLabel,
      createdAt,
      photoDataUrl,
    });
  };

  const downloadPNG = async () => {
    if (!canvasRef.current) return;
    setSaving(true);
    try {
      const canvas = canvasRef.current;
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!blob) return;

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = (card?.id || "yard-pass") + ".png";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setSaving(false);
    }
  };

  const saveToBrowser = () => {
    if (!card) return;
    try {
      localStorage.setItem("yard_pass_card_v1", JSON.stringify(card));
    } catch {
      // ignore
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Form */}
      <form onSubmit={submit} className="rounded-3xl border border-white/10 bg-black/40 p-6">
        <div className="grid gap-4">
          <Field label="Full name">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="field"
              placeholder="Your name"
              required
            />
          </Field>

          <Field label="Email">
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="field"
              placeholder="you@email.com"
              type="email"
              required
            />
          </Field>

          <Field label="Phone number">
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="field"
              placeholder="+234..."
              required
            />
          </Field>

          <Field label="Gender">
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setGender("male")}
                className={`pill ${gender === "male" ? "pillOn" : ""}`}
              >
                Male → Descendant
              </button>
              <button
                type="button"
                onClick={() => setGender("female")}
                className={`pill ${gender === "female" ? "pillOn" : ""}`}
              >
                Female → Angel
              </button>
            </div>
          </Field>

          <Field label="Upload photo">
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onPickPhoto(e.target.files?.[0])}
              className="file"
            />
            <p className="mt-2 text-xs font-semibold opacity-70">Tip: use a portrait photo for best results.</p>
          </Field>

          <button
            className="rounded-full bg-[rgb(var(--yard-yellow))] px-5 py-3 text-sm font-black text-black hover:opacity-90"
            type="submit"
          >
            Generate my card ☥
          </button>

          <style jsx>{`
            .field {
              width: 100%;
              border-radius: 16px;
              padding: 12px 14px;
              font-weight: 800;
              font-size: 13px;
              background: rgba(255, 255, 255, 0.06);
              border: 1px solid rgba(255, 255, 255, 0.1);
              color: rgba(255, 255, 255, 0.92);
              outline: none;
            }
            .field::placeholder {
              color: rgba(255, 255, 255, 0.45);
            }
            .field:focus {
              border-color: rgba(253, 208, 0, 0.35);
              box-shadow: 0 0 0 4px rgba(253, 208, 0, 0.1);
            }

            .pill {
              border-radius: 18px;
              padding: 12px 14px;
              font-weight: 900;
              font-size: 12px;
              letter-spacing: 0.1em;
              text-transform: uppercase;
              background: rgba(255, 255, 255, 0.06);
              border: 1px solid rgba(255, 255, 255, 0.1);
              color: rgba(255, 255, 255, 0.86);
              transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
            }
            .pill:hover {
              transform: translateY(-1px);
              background: rgba(255, 255, 255, 0.08);
            }
            .pillOn {
              background: rgba(253, 208, 0, 0.14);
              border-color: rgba(253, 208, 0, 0.32);
              color: rgba(255, 255, 255, 0.96);
            }

            .file {
              width: 100%;
              border-radius: 16px;
              padding: 10px 12px;
              font-weight: 800;
              font-size: 12px;
              background: rgba(255, 255, 255, 0.06);
              border: 1px solid rgba(255, 255, 255, 0.1);
              color: rgba(255, 255, 255, 0.82);
            }
          `}</style>
        </div>
      </form>

      {/* Preview + actions */}
      <div className="rounded-3xl border border-white/10 bg-black/40 p-6">
        <p className="text-xs font-black tracking-[0.22em] uppercase opacity-70">Your generated card</p>

        <div className="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-black/50">
          <canvas ref={canvasRef} className="block h-auto w-full" />
        </div>

        <div className="mt-4 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={downloadPNG}
            disabled={!card || saving}
            className="rounded-full bg-[rgb(var(--yard-yellow))] px-5 py-3 text-sm font-black text-black disabled:opacity-40"
          >
            {saving ? "Preparing..." : "Download PNG"}
          </button>

          <button
            type="button"
            onClick={saveToBrowser}
            disabled={!card}
            className="rounded-full border border-white/10 bg-white/10 px-5 py-3 text-sm font-black text-white disabled:opacity-40 hover:bg-white/12"
          >
            Save to browser
          </button>
        </div>

        <p className="mt-3 text-xs font-semibold opacity-70">
          Male → <span className="font-black">Descendant</span> • Female → <span className="font-black">Angel</span>
        </p>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-75">{label}</p>
      <div className="mt-2">{children}</div>
    </div>
  );
}

async function drawPass(canvas: HTMLCanvasElement, card: PassCard) {
  // High-res export
  const W = 1080;
  const H = 1350;

  const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.aspectRatio = `${W}/${H}`;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  // Background
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#07090C");
  bg.addColorStop(0.55, "#0B0F14");
  bg.addColorStop(1, "#06070A");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Accent glow
  const glow = ctx.createRadialGradient(W * 0.72, H * 0.18, 10, W * 0.72, H * 0.18, 520);
  glow.addColorStop(0, "rgba(253,208,0,0.28)");
  glow.addColorStop(0.45, "rgba(253,208,0,0.10)");
  glow.addColorStop(1, "rgba(253,208,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // Watermark ankh
  ctx.globalAlpha = 0.1;
  ctx.fillStyle = "rgba(253,208,0,1)";
  ctx.font = "900 420px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("☥", -70, 520);
  ctx.globalAlpha = 1;

  // Card frame
  roundedRect(ctx, 70, 80, W - 140, H - 160, 48);
  ctx.fillStyle = "rgba(255,255,255,0.06)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Header
  ctx.fillStyle = "rgba(255,255,255,0.86)";
  ctx.font = "900 26px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("THE YARD", 120, 165);

  ctx.fillStyle = "rgba(255,255,255,0.60)";
  ctx.font = "800 14px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("YARD PASS • MEMBERS ONLY", 120, 195);

  // House chip
  const chipText = card.houseLabel.toUpperCase();
  const chipW = Math.max(260, ctx.measureText(chipText).width + 80);
  roundedRect(ctx, W - 120 - chipW, 135, chipW, 54, 28);
  ctx.fillStyle = "rgba(253,208,0,0.18)";
  ctx.fill();
  ctx.strokeStyle = "rgba(253,208,0,0.35)";
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.font = "900 14px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText(chipText, W - 120 - chipW + 32, 168);

  // Photo block
  const px = 120;
  const py = 245;
  const pw = W - 240;
  const ph = 700;

  roundedRect(ctx, px, py, pw, ph, 42);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.stroke();

  if (card.photoDataUrl) {
    const img = await loadImage(card.photoDataUrl);
    // cover fit
    const scale = Math.max(pw / img.width, ph / img.height);
    const iw = img.width * scale;
    const ih = img.height * scale;
    const ix = px + (pw - iw) / 2;
    const iy = py + (ph - ih) / 2;

    ctx.save();
    roundedRect(ctx, px, py, pw, ph, 42);
    ctx.clip();
    ctx.drawImage(img, ix, iy, iw, ih);
    ctx.restore();

    // glaze
    const glaze = ctx.createLinearGradient(0, py, 0, py + ph);
    glaze.addColorStop(0, "rgba(0,0,0,0.10)");
    glaze.addColorStop(0.65, "rgba(0,0,0,0.00)");
    glaze.addColorStop(1, "rgba(0,0,0,0.40)");
    ctx.fillStyle = glaze;
    roundedRect(ctx, px, py, pw, ph, 42);
    ctx.fill();
  } else {
    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.font = "900 22px system-ui, -apple-system, Segoe UI, Roboto";
    ctx.fillText("Upload a photo for the full look.", px + 40, py + 70);
  }

  // Name
  ctx.fillStyle = "rgba(255,255,255,0.96)";
  ctx.font = "900 56px system-ui, -apple-system, Segoe UI, Roboto";
  wrapText(ctx, card.name.toUpperCase(), 120, 1035, W - 240, 62);

  // Details
  ctx.fillStyle = "rgba(255,255,255,0.72)";
  ctx.font = "800 20px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText(card.email, 120, 1132);
  ctx.fillText(card.phone, 120, 1166);

  // Footer ID
  roundedRect(ctx, 120, 1200, W - 240, 92, 28);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fill();
  ctx.strokeStyle = "rgba(253,208,0,0.28)";
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.78)";
  ctx.font = "900 14px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas";
  ctx.fillText(`ID: ${card.id}`, 150, 1240);

  ctx.fillStyle = "rgba(255,255,255,0.55)";
  ctx.font = "800 14px system-ui, -apple-system, Segoe UI, Roboto";
  const issued = `Issued: ${card.createdAt}`;
  ctx.fillText(issued, W - 150 - ctx.measureText(issued).width, 1240);

  // Small mark
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = "rgba(253,208,0,1)";
  ctx.font = "900 140px system-ui, -apple-system, Segoe UI, Roboto";
  ctx.fillText("☥", W - 240, H - 120);
  ctx.globalAlpha = 1;
}

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxW: number, lineH: number) {
  const words = text.split(" ");
  let line = "";
  let yy = y;

  for (let i = 0; i < words.length; i++) {
    const test = line ? `${line} ${words[i]}` : words[i];
    const w = ctx.measureText(test).width;
    if (w > maxW && line) {
      ctx.fillText(line, x, yy);
      line = words[i];
      yy += lineH;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, yy);
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new window.Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
