"use client";

import React from "react";

export default function OutroSection() {
  return (
    <section className="paper-card relative overflow-hidden p-10">
      <div className="absolute inset-0 microgrid opacity-[0.18]" />
      <div className="absolute inset-0 vignette-soft" />
      <div className="absolute inset-0 grain opacity-[0.12]" />

      <div className="relative flex flex-wrap items-center justify-between gap-6">
        <div>
          <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/60">
            THE YARD
          </p>
          <h3 className="mt-2 text-4xl font-black text-black">You’re early.</h3>
          <p className="mt-2 text-sm font-semibold muted">
            Generate your pass — then sign in anytime.
          </p>
        </div>

        <a
          href="#pass"
          className="rounded-full bg-[rgb(var(--yard-yellow))] px-8 py-4 text-sm font-black text-black hover:opacity-90 shadow-[0_22px_70px_rgba(0,0,0,0.25)]"
        >
          Generate Yard Pass ☥
        </a>
      </div>
    </section>
  );
}
