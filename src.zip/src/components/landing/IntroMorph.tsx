"use client";

import React, { useLayoutEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useReducedMotion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import HeroStage from "@/components/landing/HeroStage";

gsap.registerPlugin(ScrollTrigger);

export default function IntroMorph() {
  const prefersReduced = useReducedMotion();

  const pinRef = useRef<HTMLElement | null>(null);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const overlayImgRef = useRef<HTMLDivElement | null>(null);
  const overlayCopyRef = useRef<HTMLDivElement | null>(null);
  const heroRevealRef = useRef<HTMLDivElement | null>(null);
  const navDarkRef = useRef<HTMLDivElement | null>(null);
  const navLightRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (prefersReduced) {
      // If reduced motion, show the hero immediately.
      if (overlayRef.current) overlayRef.current.style.opacity = "0";
      if (navDarkRef.current) navDarkRef.current.style.opacity = "0";
      if (navLightRef.current) navLightRef.current.style.opacity = "1";
      if (heroRevealRef.current) heroRevealRef.current.style.opacity = "1";
      return;
    }
    if (!pinRef.current || !overlayRef.current || !overlayImgRef.current || !heroRevealRef.current) return;

    const ctx = gsap.context(() => {
      gsap.set(heroRevealRef.current, { opacity: 0, y: 26, filter: "blur(10px)" });
      gsap.set(overlayRef.current, { opacity: 1 });
      gsap.set(overlayImgRef.current, { scale: 1, filter: "blur(0px)" });
      gsap.set(overlayCopyRef.current, { opacity: 1, y: 0 });
      gsap.set(navDarkRef.current, { opacity: 1 });
      gsap.set(navLightRef.current, { opacity: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: pinRef.current!,
          start: "top top",
          end: "+=160%",
          scrub: 1,
          pin: true,
          pinReparent: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Make the cover feel alive while it dissolves
      tl.to(
        overlayImgRef.current!,
        { scale: 1.08, filter: "blur(18px)", duration: 1, ease: "none" },
        0
      );

      // Fade copy first (so the hero doesn't fight the text)
      tl.to(
        overlayCopyRef.current!,
        { opacity: 0, y: 18, filter: "blur(6px)", duration: 0.6, ease: "none" },
        0.08
      );

      // Dissolve the cover layer
      tl.to(overlayRef.current!, { opacity: 0, duration: 1, ease: "none" }, 0.12);

      // Swap nav color system
      tl.to(navDarkRef.current!, { opacity: 0, duration: 0.35, ease: "none" }, 0.16);
      tl.to(navLightRef.current!, { opacity: 1, duration: 0.35, ease: "none" }, 0.28);

      // Reveal the hero under the cover
      tl.to(
        heroRevealRef.current!,
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1, ease: "none" },
        0.04
      );
    }, pinRef);

    return () => ctx.revert();
  }, [prefersReduced]);

  const refreshST = () => {
    if (prefersReduced) return;
    requestAnimationFrame(() => ScrollTrigger.refresh());
  };

  return (
    <section
      ref={(n) => {
        pinRef.current = n;
      }}
      className="introPin relative overflow-hidden bg-black"
      aria-label="Intro reveal"
    >
      {/* HERO UNDERLAYER */}
      <div ref={heroRevealRef} className="relative">
        <HeroStage />
      </div>

      {/* INTRO OVERLAY (photo + copy) */}
      <div
        ref={(n) => {
          overlayRef.current = n;
        }}
        className="introOverlay absolute inset-0"
      >
        <div
          ref={(n) => {
            overlayImgRef.current = n;
          }}
          className="absolute inset-0"
        >
          <Image
            src="/Pictures/yard.jpg"
            alt="The Yard"
            fill
            priority
            sizes="100vw"
            className="object-cover"
            onLoadingComplete={refreshST}
          />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.10),transparent_48%)]" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-black/55 to-black/85" />
          <div className="absolute inset-0 vignette-dark" />
          <div className="absolute inset-0 grain opacity-[0.22]" />
        </div>

        {/* Dark nav (white on photo) */}
        <div
          ref={navDarkRef}
          className="fixed left-0 right-0 top-0 z-30"
          aria-hidden={prefersReduced ? true : false}
        >
          <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 md:px-10">
            <Link href="/" className="flex items-center gap-3">
              <span className="text-2xl font-black text-white">☥</span>
              <span className="text-sm font-black tracking-[0.22em] text-white/90">THE YARD</span>
            </Link>

            <div className="hidden items-center gap-7 md:flex">
              <a href="#houses" className="navLinkWhite">
                Houses
              </a>
              <a href="#feed" className="navLinkWhite">
                Feed
              </a>
              <a href="#pass" className="navLinkWhite">
                Yard Pass
              </a>
              <Link href="/profile" className="navBtnWhite">
                Sign in
              </Link>
            </div>
          </div>
        </div>

        {/* Light nav (black) — fades in after reveal */}
        <div
          ref={navLightRef}
          className="fixed left-0 right-0 top-0 z-30"
          aria-hidden={prefersReduced ? false : false}
        >
          <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 md:px-10">
            <Link href="/" className="flex items-center gap-3">
              <span className="text-2xl font-black text-black">☥</span>
              <span className="text-sm font-black tracking-[0.22em] text-black/80">THE YARD</span>
            </Link>

            <div className="hidden items-center gap-7 md:flex">
              <a href="#houses" className="navLinkBlack">
                Houses
              </a>
              <a href="#feed" className="navLinkBlack">
                Feed
              </a>
              <a href="#pass" className="navLinkBlack">
                Yard Pass
              </a>
              <Link href="/profile" className="navBtnBlack">
                Sign in
              </Link>
            </div>
          </div>
        </div>

        {/* White manifesto copy */}
        <div
          ref={overlayCopyRef}
          className="relative z-10 mx-auto flex h-full max-w-6xl items-end px-6 pb-12 md:px-10 md:pb-16"
        >
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chipDark">Enter the Yard</span>
              <span className="chipDark">Get your ID ready</span>
              <span className="chipDark">Members-only</span>
            </div>

            <h1 className="mt-6 text-5xl font-black leading-[0.95] text-white md:text-7xl">
              Enter the Yard.
            </h1>

            <p className="mt-4 max-w-xl text-base font-semibold text-white/85 md:text-lg">
              Not a public page. Not a regular sign-up.
              <span className="font-black text-white"> Your ID is your entry.</span>
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#pass" className="ctaWhite">
                Generate my Yard Pass ☥
              </a>
              <a href="#houses" className="ctaGhostWhite">
                Choose a house
              </a>
            </div>

            <p className="mt-4 text-xs font-black tracking-[0.22em] text-white/60 uppercase">
              Scroll to reveal
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
