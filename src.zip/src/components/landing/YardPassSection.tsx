"use client";

import React from "react";
import PassGenerator from "@/components/landing/pass/PassGenerator";
import { Caption } from "@/components/landing/atoms";

export default function YardPassSection() {
  return (
    <section id="pass" className="grid gap-5 lg:grid-cols-2">
      <div className="ink-card relative overflow-hidden p-10">
        <div className="absolute inset-0 opacity-[0.60]">
          <div className="absolute inset-0 vignette-dark" />
          <div className="absolute inset-0 grain" />
        </div>

        <div className="relative">
          <Caption>YARD PASS</Caption>
          <h2 className="mt-4 text-4xl font-black tracking-tight text-[rgb(var(--yard-yellow))]">
            Generate your ID.
          </h2>
          <p className="mt-3 max-w-xl text-[15px] font-semibold text-white/70">
            Your pass is your entry. Pick your house, upload a photo, and export a clean card.
          </p>

          <div className="mt-7">
            <PassGenerator />
          </div>
        </div>
      </div>

      <div className="grid gap-5">
        <div className="paper-card p-10">
          <Caption>WHY</Caption>
          <h3 className="mt-4 text-2xl font-black tracking-tight">Real updates. No noise.</h3>
          <p className="mt-3 text-[15px] font-semibold opacity-70">
            Once you have a pass, you get house-specific drops, show dates, and private links.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <span className="chip">Show updates</span>
            <span className="chip">News</span>
            <span className="chip">Early links</span>
            <span className="chip">House perks</span>
          </div>
        </div>

        <div className="yard-frame corner-stamps overflow-hidden">
          <div className="p-10">
            <Caption>RULES</Caption>
            <h3 className="mt-4 text-2xl font-black tracking-tight">Keep it simple.</h3>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-[15px] font-semibold opacity-70">
              <li>No spam — one pass per person.</li>
              <li>House is assigned by your pick.</li>
              <li>We only use your info for Yard updates.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
