"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
} from "framer-motion";

export function Caption({ children }: { children: React.ReactNode }) {
  return (
    <div className="caption">
      <span className="captionDot" />
      <span className="truncate">{children}</span>
    </div>
  );
}

export function Stat({ k, v }: { k: string; v: string }) {
  const prefersReduced = useReducedMotion();
  return (
    <motion.div
      whileHover={prefersReduced ? undefined : { y: -2, scale: 1.01 }}
      transition={{ duration: 0.18 }}
      className="yard-frame corner-stamps p-5 lift"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(0,0,0,0.05),transparent_40%)]" />
      <div className="absolute inset-0 grain opacity-[0.10]" />
      <div className="relative">
        <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-black/55">{k}</p>
        <p className="mt-1 text-2xl font-black text-black">{v}</p>
        <div className="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-black/10">
          <motion.div
            className="h-2 w-2/3 rounded-full bg-black/20"
            whileHover={prefersReduced ? undefined : { x: 6 }}
            transition={{ type: "spring", stiffness: 220, damping: 20 }}
          />
          <div className="shimmer absolute inset-0 opacity-15 mask-fade" />
        </div>
      </div>
    </motion.div>
  );
}

export function MagneticLink({
  href,
  className,
  children,
}: {
  href: string;
  className: string;
  children: React.ReactNode;
}) {
  const prefersReduced = useReducedMotion();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 260, damping: 22, mass: 0.35 });
  const sy = useSpring(y, { stiffness: 260, damping: 22, mass: 0.35 });

  return (
    <motion.div
      style={prefersReduced ? undefined : { x: sx, y: sy }}
      onMouseMove={(e) => {
        if (prefersReduced) return;
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2);
        const dy = e.clientY - (r.top + r.height / 2);
        x.set(dx * 0.12);
        y.set(dy * 0.12);

        const pct = Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100));
        (e.currentTarget as HTMLElement).style.setProperty("--sx", `${pct}%`);
      }}
      onMouseLeave={(e) => {
        x.set(0);
        y.set(0);
        (e.currentTarget as HTMLElement).style.setProperty("--sx", `50%`);
      }}
      className="inline-flex"
    >
      <Link href={href} className={className}>
        {children}
      </Link>
    </motion.div>
  );
}

export function TiltCard({
  className,
  children,
}: {
  className: string;
  children: React.ReactNode;
}) {
  const prefersReduced = useReducedMotion();
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 220, damping: 22, mass: 0.35 });
  const sry = useSpring(ry, { stiffness: 220, damping: 22, mass: 0.35 });

  return (
    <motion.div
      className={className}
      style={
        prefersReduced
          ? undefined
          : {
              transformStyle: "preserve-3d",
              rotateX: srx,
              rotateY: sry,
            }
      }
      onMouseMove={(e) => {
        if (prefersReduced) return;
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        ry.set((px - 0.5) * 10);
        rx.set(-(py - 0.5) * 8);
      }}
      onMouseLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
    >
      <div
        className="relative h-full w-full"
        style={prefersReduced ? undefined : ({ transform: "translateZ(18px)" } as any)}
      >
        {children}
      </div>
    </motion.div>
  );
}

export function Poster({
  src,
  label,
  wide,
  priority,
}: {
  src: string;
  label: string;
  wide?: boolean;
  priority?: boolean;
}) {
  return (
    <TiltCard
      className={[
        "group yard-frame corner-stamps lift border-shimmer",
        wide ? "h-56 md:h-64" : "h-44 md:h-48",
      ].join(" ")}
    >
      <div className="absolute inset-0">
        <Image
          src={src}
          alt={label}
          fill
          priority={priority}
          sizes={wide ? "(min-width: 768px) 520px, 100vw" : "(min-width: 768px) 260px, 50vw"}
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
        />
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/35" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.30),transparent_42%)] mix-blend-overlay" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_85%,rgba(255,210,0,0.18),transparent_55%)] mix-blend-multiply" />
      <div className="absolute inset-0 grain opacity-[0.18]" />

      <div className="pointer-events-none absolute right-4 top-4 text-3xl font-black text-white/20 drop-shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
        ☥
      </div>

      <div className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute inset-0 bg-[linear-gradient(115deg,transparent,rgba(255,255,255,0.20),transparent)] translate-x-[-60%] group-hover:translate-x-[60%] transition-transform duration-700 ease-out" />
      </div>
    </TiltCard>
  );
}

export function HouseCard({
  title,
  badge,
  desc,
}: {
  title: string;
  badge: string;
  desc: string;
}) {
  return (
    <TiltCard className="ink-card relative overflow-hidden p-8 lift border-shimmer">
      <div className="absolute -right-10 -top-10 text-[200px] font-black text-[rgb(var(--yard-yellow))]/10">
        ☥
      </div>
      <div className="absolute inset-0 grain opacity-[0.10]" />

      <div className="relative flex items-start justify-between gap-4">
        <div>
          <p className="text-xl font-black">{title}</p>
          <p className="mt-3 text-sm font-semibold opacity-80">{desc}</p>
        </div>

        <span className="rounded-2xl bg-[rgb(var(--yard-yellow))] px-4 py-2 text-xs font-black text-black shadow-[0_18px_50px_rgba(0,0,0,0.18)]">
          {badge}
        </span>
      </div>

      <div className="relative mt-6 rounded-2xl border border-[rgb(var(--yard-yellow))]/20 bg-black/40 px-4 py-3">
        <div className="flex items-center justify-between text-xs font-black opacity-85">
          <span>Access</span>
          <span>Members-only</span>
        </div>
      </div>
    </TiltCard>
  );
}

export function FeedCard({ title }: { title: string }) {
  const prefersReduced = useReducedMotion();
  return (
    <motion.div
      whileHover={prefersReduced ? undefined : { y: -2, scale: 1.01 }}
      transition={{ duration: 0.18 }}
      className="yard-frame p-6 lift"
    >
      <div className="absolute inset-0 backdrop-blur-[8px]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,rgba(0,0,0,0.06),transparent_40%)]" />
      <div className="absolute inset-0 grain opacity-[0.10]" />

      <div className="relative space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-sm font-black text-black">{title}</p>
          <span className="rounded-full bg-black px-3 py-1 text-xs font-black text-[rgb(var(--yard-yellow))]">
            🔒
          </span>
        </div>

        <div className="space-y-2">
          <div className="h-2 w-5/6 rounded-full bg-black/15" />
          <div className="h-2 w-4/6 rounded-full bg-black/10" />
          <div className="h-2 w-3/6 rounded-full bg-black/10" />
        </div>

        <p className="pt-1 text-xs font-bold text-black/60">Sign in to view this update.</p>
      </div>

      <div className="shimmer absolute inset-0 opacity-[0.08] mask-fade" />
    </motion.div>
  );
}

export function AnkhPattern() {
  return (
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="ankh" x="0" y="0" width="140" height="140" patternUnits="userSpaceOnUse">
          <text x="18" y="88" fontSize="64" fontWeight="900" fill="rgba(255,210,0,0.25)">
            ☥
          </text>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#ankh)" />
    </svg>
  );
}
