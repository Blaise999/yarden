// src/components/landing/HeroStage.tsx
"use client";

import React, { useMemo, useRef } from "react";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import { Caption, MagneticLink, Poster, Stat } from "@/components/landing/atoms";

export type HeroPoster = {
  src: string;
  label: string;
  wide?: boolean;
};

export default function HeroStage() {
  const prefersReduced = useReducedMotion();

  const heroParallaxRef = useRef<HTMLElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: heroParallaxRef,
    offset: ["start end", "end start"],
  });

  const wmY = useTransform(
    scrollYProgress,
    [0, 1],
    prefersReduced ? [0, 0] : [30, -30]
  );
  const galleryY = useTransform(
    scrollYProgress,
    [0, 1],
    prefersReduced ? [0, 0] : [22, -22]
  );

  // Cursor glow
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const gx = useSpring(mx, { stiffness: 240, damping: 32, mass: 0.35 });
  const gy = useSpring(my, { stiffness: 240, damping: 32, mass: 0.35 });

  const posters = useMemo<HeroPoster[]>(
    () => [
      { src: "/Pictures/yarden1.png", label: "Yarden • Portrait 01" },
      { src: "/Pictures/yarden2.png", label: "Yarden • Portrait 02" },
      { src: "/Pictures/yarden3.png", label: "Yarden • Portrait 03" },
      { src: "/Pictures/yarden4.png", label: "Studio / Wide Cover", wide: true },
    ],
    []
  );

  return (
    <section
      ref={(n) => {
        heroParallaxRef.current = n;
      }}
      onPointerMove={(e) => {
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        mx.set(e.clientX - r.left);
        my.set(e.clientY - r.top);
      }}
      className="heroStage relative overflow-hidden bg-yellow-200/15"
    >
      {/* wallpaper + depth */}
      <div className="absolute inset-0 ankh-wall" />
      <div className="absolute inset-0 microgrid opacity-[0.22]" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/18" />
      <div className="absolute inset-0 vignette" />
      <div className="absolute inset-0 grain opacity-[0.20]" />

      {/* cursor spotlight */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
        style={prefersReduced ? undefined : { left: gx, top: gy }}
      >
        <div className="h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle,rgba(255,210,0,0.32),rgba(255,210,0,0.10),rgba(255,210,0,0))] blur-2xl" />
      </motion.div>

      {/* watermark */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -left-10 top-8 select-none text-[280px] font-black text-black/[0.055]"
        style={prefersReduced ? undefined : { y: wmY }}
      >
        ☥
      </motion.div>

      <div className="relative grid gap-10 p-10 md:grid-cols-[1.15fr_0.85fr] md:p-14">
        {/* COPY */}
        <div className="space-y-7">
          <div className="flex flex-wrap items-center gap-2">
            <span className="chip">THE YARD</span>
            <span className="chip">Members-only signal</span>
            <span className="chip">Drops • Notes • Updates</span>
          </div>

          <h1 className="title-display text-5xl font-black text-black md:text-7xl">
            The Yard is a doorway.
            <span className="block text-black/80">Not a feed. Not noise.</span>
            <span className="block underline decoration-black/15 underline-offset-8">
              First access.
            </span>
          </h1>

          <p className="max-w-xl text-lg font-semibold muted">
            Pick a house. Generate your Yard Pass. Unlock private updates.
            <span className="font-black text-black"> Your ID is your entry.</span>
          </p>

          <div className="flex flex-wrap gap-3">
            <MagneticLink href="#pass" className="btn-ink">
              <span className="relative z-10">Generate Yard Pass ☥</span>
              <span aria-hidden className="btn-shine" />
            </MagneticLink>

            <MagneticLink href="/profile" className="btn-ghost">
              I already have an ID
            </MagneticLink>
          </div>

          <div className="grid gap-4 pt-2 sm:grid-cols-3">
            <Stat k="ACCESS" v="PRIVATE" />
            <Stat k="HOUSE" v="CHOSEN" />
            <Stat k="PASS" v="GENERATED" />
          </div>
        </div>

        {/* VISUALS */}
        <motion.div
          style={prefersReduced ? undefined : { y: galleryY }}
          className="space-y-5"
        >
          <div className="grid grid-cols-2 gap-4">
            <Poster src={posters[0].src} label={posters[0].label} priority />
            <Poster src={posters[1].src} label={posters[1].label} />
            <Poster src={posters[2].src} label={posters[2].label} />
            <div className="col-span-2">
              <Poster src={posters[3].src} label={posters[3].label} wide />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Caption>{posters[0].label}</Caption>
            <Caption>{posters[1].label}</Caption>
            <Caption>{posters[2].label}</Caption>
            <div className="col-span-2">
              <Caption>{posters[3].label}</Caption>
            </div>
          </div>

          <div className="ink-card relative overflow-hidden p-6 lift border-shimmer">
            <div className="absolute -right-10 -top-10 text-[180px] font-black text-[rgb(var(--yard-yellow))]/10">
              ☥
            </div>

            <div className="relative flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-80">
                  Yard Pass (Preview)
                </p>
                <h3 className="mt-2 text-xl font-black">Members-only access.</h3>
                <p className="mt-1 text-sm font-semibold opacity-80">
                  Generate your ID below and download your card.
                </p>
              </div>

              <div className="rounded-2xl bg-[rgb(var(--yard-yellow))] px-4 py-3 text-black shadow-[0_18px_50px_rgba(0,0,0,0.2)]">
                <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] opacity-70">
                  Status
                </p>
                <p className="text-sm font-black">ACTIVE</p>
              </div>
            </div>

            <div className="relative mt-5 rounded-2xl border border-[rgb(var(--yard-yellow))]/25 bg-black/40 px-4 py-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black opacity-80">ID</span>
                <span className="font-mono text-xs font-black tracking-wider">
                  YARD-25-XXXXXXXX
                </span>
              </div>

              <div className="relative mt-3 h-2 w-full overflow-hidden rounded-full bg-[rgb(var(--yard-yellow))]/10">
                <motion.div
                  className="h-2 rounded-full bg-[rgb(var(--yard-yellow))]/40"
                  initial={prefersReduced ? undefined : { width: "18%" }}
                  animate={prefersReduced ? undefined : { width: "66%" }}
                  transition={{ duration: 1.1, ease: "easeOut" }}
                />
                <div className="shimmer absolute inset-0 opacity-20 mask-fade" />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
