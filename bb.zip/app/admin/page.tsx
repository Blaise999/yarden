import AdminPage from "./AdminPage.client";

export default function Page() {
  return <AdminPage />;
}
