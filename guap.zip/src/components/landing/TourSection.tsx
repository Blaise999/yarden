// src/components/landing/TourSection.tsx
"use client";

import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

import {
  Badge,
  Button,
  Card,
  Divider,
  IconAnkh,
  IconArrowUpRight,
  IconChevron,
  IconClose,
  Modal,
  Pill,
  SectionHeader,
  Stat,
  cx,
  usePrefersReducedMotion,
} from "@/components/landing/ui";

export type ShowStatus = "tickets" | "soldout" | "announce";

export type ShowItem = {
  id: string;
  dateISO?: string;     // preferred for real data (e.g. "2026-04-12")
  dateLabel?: string;   // fallback (e.g. "APR 12")
  city: string;
  venue: string;
  href?: string;        // ticket/details link
  status?: ShowStatus;
};

export type TourConfig = {
  headline?: string;
  description?: string;

  posterSrc: string;
  posterAlt?: string;

  ticketPortalHref?: string;
  notifyCtaLabel?: string;

  // purely for messaging / future integration
  providerHint?: "Bandsintown" | "Seated" | "Custom";
};

function formatShortDate(show: ShowItem) {
  // If ISO exists, render "APR" + "12"
  if (show.dateISO) {
    const d = new Date(show.dateISO + "T00:00:00");
    const month = d.toLocaleString("en-US", { month: "short" }).toUpperCase();
    const day = String(d.getDate()).padStart(2, "0");
    return { month, day };
  }

  // If label like "APR 12"
  if (show.dateLabel) {
    const parts = show.dateLabel.trim().split(/\s+/);
    const month = (parts[0] || "—").toUpperCase();
    const day = (parts[1] || "—").toUpperCase();
    return { month, day };
  }

  return { month: "—", day: "—" };
}

function statusPill(status?: ShowStatus) {
  if (status === "soldout") return <Pill tone="muted">Sold out</Pill>;
  if (status === "announce") return <Pill tone="muted">Announcing soon</Pill>;
  return <Pill tone="brand">Tickets</Pill>;
}

const STORAGE_KEY = "yarden:tour:draft:v1";

export function TourSection(props: {
  id?: string;
  shows: ShowItem[];
  config: TourConfig;

  // user actions
  onOpenPass?: () => void;
  onNotify?: () => void;

  // admin editing contract (optional)
  editable?: boolean; // show “Edit tour” button and modal
  onSave?: (payload: { shows: ShowItem[]; config: TourConfig }) => Promise<void> | void;

  // Optional override to fetch future real data (you can ignore for now)
  // dataSourceLabel?: string;
}) {
  const reducedMotion = usePrefersReducedMotion();
  const id = props.id ?? "shows";

  const rootRef = useRef<HTMLDivElement | null>(null);

  // ----- public UI filters (small but useful) -----
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | ShowStatus>("all");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return props.shows.filter((s) => {
      const matchesQuery = !q || `${s.city} ${s.venue}`.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "all" || (s.status ?? "tickets") === statusFilter;
      return matchesQuery && matchesStatus;
    });
  }, [props.shows, query, statusFilter]);

  // ----- admin editing modal -----
  const [editOpen, setEditOpen] = useState(false);
  const [draftShows, setDraftShows] = useState<ShowItem[]>(props.shows);
  const [draftConfig, setDraftConfig] = useState<TourConfig>(props.config);
  const [saving, setSaving] = useState(false);

  // keep draft in sync when props change (unless editing is open)
  useEffect(() => {
    if (editOpen) return;
    setDraftShows(props.shows);
    setDraftConfig(props.config);
  }, [props.shows, props.config, editOpen]);

  // load local draft if editable and present (nice for “admin can edit anytime” even before DB exists)
  useEffect(() => {
    if (!props.editable) return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed?.shows && parsed?.config) {
        setDraftShows(parsed.shows);
        setDraftConfig(parsed.config);
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.editable]);

  const persistDraft = (shows: ShowItem[], config: TourConfig) => {
    if (!props.editable) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ shows, config, updatedAt: Date.now() }));
    } catch {}
  };

  const addShow = () => {
    const next: ShowItem = {
      id: crypto?.randomUUID?.() ?? `show_${Math.random().toString(16).slice(2)}`,
      dateISO: "",
      dateLabel: "",
      city: "",
      venue: "",
      href: "",
      status: "announce",
    };
    const updated = [next, ...draftShows];
    setDraftShows(updated);
    persistDraft(updated, draftConfig);
  };

  const removeShow = (id: string) => {
    const updated = draftShows.filter((s) => s.id !== id);
    setDraftShows(updated);
    persistDraft(updated, draftConfig);
  };

  const updateShow = (id: string, patch: Partial<ShowItem>) => {
    const updated = draftShows.map((s) => (s.id === id ? { ...s, ...patch } : s));
    setDraftShows(updated);
    persistDraft(updated, draftConfig);
  };

  const saveNow = async () => {
    setSaving(true);
    try {
      // Always persist draft locally so you don’t lose edits even without backend
      persistDraft(draftShows, draftConfig);

      // If you already have an admin backend later, you’ll wire this to a real save.
      if (props.onSave) await props.onSave({ shows: draftShows, config: draftConfig });

      setEditOpen(false);
    } finally {
      setSaving(false);
    }
  };

  // ----- GSAP polish: section reveal + rows stagger -----
  useLayoutEffect(() => {
    if (reducedMotion) return;

    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      const root = rootRef.current;
      if (!root) return;

      const rows = Array.from(root.querySelectorAll<HTMLElement>("[data-show-row='true']"));
      const poster = root.querySelector<HTMLElement>("[data-tour-poster='true']");
      const shell = root.querySelector<HTMLElement>("[data-tour-shell='true']");

      if (shell) {
        gsap.fromTo(
          shell,
          { y: 14, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: { trigger: root, start: "top 75%", once: true },
          }
        );
      }

      if (poster) {
        gsap.fromTo(
          poster,
          { y: 18, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: { trigger: root, start: "top 75%", once: true },
          }
        );
      }

      if (rows.length) {
        gsap.fromTo(
          rows,
          { y: 12, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: "power3.out",
            stagger: 0.06,
            scrollTrigger: { trigger: root, start: "top 70%", once: true },
          }
        );
      }
    }, rootRef);

    return () => ctx.revert();
  }, [reducedMotion, filtered.length]);

  const cfg = props.config;
  const total = props.shows.length;
  const announced = props.shows.filter((s) => (s.status ?? "tickets") !== "announce").length;

  return (
    <section id={id} className="relative py-20 md:py-24">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,rgba(255,255,255,0.08),transparent_55%)]" />
      </div>

      <div ref={rootRef} className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeader
          eyebrow="Tour"
          title={cfg.headline ?? "Shows that feel like chapters."}
          desc={
            cfg.description ??
            "Right now it’s a clean placeholder. Later, the admin panel will update dates instantly — no redesign needed."
          }
          right={
            <div className="flex flex-wrap gap-2">
              {props.editable ? (
                <Button variant="secondary" onClick={() => setEditOpen(true)}>
                  Edit tour
                </Button>
              ) : null}

              <Button
                variant="ghost"
                onClick={() => (props.onNotify ? props.onNotify() : alert("Later: enable show alerts via email/SMS"))}
                iconRight={<IconChevron className="h-4 w-4" />}
              >
                {cfg.notifyCtaLabel ?? "Get alerts"}
              </Button>

              {cfg.ticketPortalHref ? (
                <Button
                  variant="secondary"
                  href={cfg.ticketPortalHref}
                  target="_blank"
                  iconRight={<IconArrowUpRight className="h-4 w-4" />}
                >
                  Ticket portal
                </Button>
              ) : (
                <Button
                  variant="secondary"
                  onClick={() => alert("Later: connect your ticket platform (Seated/Bandsintown/Shopify)")}
                >
                  Ticket portal
                </Button>
              )}
            </div>
          }
        />

        {/* Small stats + filters */}
        <div className="mb-6 grid gap-4 lg:grid-cols-[1fr_1fr_1fr]">
          <Stat label="Dates" value={String(total)} hint="Loaded from data" />
          <Stat label="Announced" value={String(announced)} hint="Tickets / sold-out" />
          <div className="rounded-2xl bg-white/[0.04] p-5 ring-1 ring-white/10">
            <div className="text-xs uppercase tracking-widest text-white/60">Search</div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="City or venue…"
                className={cx(
                  "w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                  "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                )}
              />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className={cx(
                  "w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white",
                  "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                )}
              >
                <option value="all" className="bg-[#0B0B10]">
                  All statuses
                </option>
                <option value="tickets" className="bg-[#0B0B10]">
                  Tickets
                </option>
                <option value="announce" className="bg-[#0B0B10]">
                  Announcing soon
                </option>
                <option value="soldout" className="bg-[#0B0B10]">
                  Sold out
                </option>
              </select>
            </div>
          </div>
        </div>

        {/* Main card */}
        <Card className="overflow-hidden" data-tour-shell="true">
          <div className="grid lg:grid-cols-[1.2fr_.8fr]">
            {/* Left: list */}
            <div className="p-6 md:p-8">
              <div className="flex flex-wrap items-center gap-2">
                <Badge>Data-driven</Badge>
                <Badge>Admin-updatable</Badge>
                <Badge>{cfg.providerHint ? `Widget later: ${cfg.providerHint}` : "Widget ready"}</Badge>
              </div>

              <div className="mt-6 divide-y divide-white/10">
                {filtered.length ? (
                  filtered.map((s) => {
                    const d = formatShortDate(s);
                   const link = s.href || cfg.ticketPortalHref;
const hasRealLink = !!link;


                    return (
                      <div key={s.id} className="flex items-center justify-between gap-6 py-5" data-show-row="true">
                        <div className="flex items-center gap-5">
                          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/[0.04] ring-1 ring-white/10">
                            <div className="text-center">
                              <div className="text-xs font-semibold tracking-wide text-white/80">{d.month}</div>
                              <div className="text-base font-semibold tracking-tight">{d.day}</div>
                            </div>
                          </div>

                          <div>
                            <div className="text-base font-semibold text-white">{s.city || "—"}</div>
                            <div className="mt-0.5 text-sm text-white/60">{s.venue || "Venue TBA"}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {statusPill(s.status)}

                        <Button
  variant="ghost"
  href={link ?? "#"}
  target={hasRealLink ? "_blank" : undefined}
  iconRight={<IconArrowUpRight className="h-4 w-4" />}
  className="px-4 py-2"
  disabled={!hasRealLink}
>
  Details
</Button>

                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-10">
                    <div className="rounded-3xl bg-white/[0.03] p-7 ring-1 ring-white/10">
                      <div className="flex items-center gap-2 text-white/70">
                        <IconAnkh className="h-5 w-5" />
                        <div className="text-xs uppercase tracking-widest">No dates yet</div>
                      </div>
                      <div className="mt-4 text-lg font-semibold">Nothing announced right now.</div>
                      <p className="mt-2 text-sm leading-relaxed text-white/60">
                        That’s fine. Keep this section as the official home for tour info — when dates drop, admin updates
                        the data and the page stays clean.
                      </p>
                      <div className="mt-5 flex flex-wrap gap-2">
                        <Button
                          variant="primary"
                          onClick={() => (props.onNotify ? props.onNotify() : alert("Later: enable show alerts"))}
                        >
                          Get alerts
                        </Button>
                        <Button variant="secondary" onClick={() => props.onOpenPass?.()}>
                          Pass perks
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <Divider />

              <div className="grid gap-4 md:grid-cols-3">
                <Card className="p-5">
                  <div className="text-xs uppercase tracking-widest text-white/60">Admin-ready</div>
                  <div className="mt-2 text-sm text-white/70">
                    Dates come from data, not hardcoded layout.
                  </div>
                </Card>
                <Card className="p-5">
                  <div className="text-xs uppercase tracking-widest text-white/60">Instant updates</div>
                  <div className="mt-2 text-sm text-white/70">
                    Swap the list anytime without changing the design.
                  </div>
                </Card>
                <Card className="p-5">
                  <div className="text-xs uppercase tracking-widest text-white/60">Widget later</div>
                  <div className="mt-2 text-sm text-white/70">
                    Bandsintown/Seated can replace the list when ready.
                  </div>
                </Card>
              </div>
            </div>

            {/* Right: poster */}
            <div className="relative min-h-[360px]" data-tour-poster="true">
              <Image
                src={cfg.posterSrc}
                alt={cfg.posterAlt ?? "Tour poster"}
                fill
                sizes="(max-width: 1024px) 100vw, 40vw"
                className="object-cover"
                priority={false}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />

              <div className="absolute bottom-6 left-6 right-6">
                <div className="rounded-3xl bg-black/40 p-5 ring-1 ring-white/10 backdrop-blur-xl">
                  <div className="text-xs uppercase tracking-[0.28em] text-white/60">Tour mode</div>
                  <div className="mt-2 text-lg font-semibold">Make it official here.</div>
                  <p className="mt-2 text-sm text-white/60">
                    This block stays the same. Only the data changes — cities, dates, links.
                  </p>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {cfg.ticketPortalHref ? (
                      <Button variant="primary" href={cfg.ticketPortalHref} target="_blank" iconRight={<IconArrowUpRight className="h-4 w-4" />}>
                        Ticket portal
                      </Button>
                    ) : (
                      <Button variant="primary" onClick={() => alert("Later: open ticket platform")}>
                        Ticket portal
                      </Button>
                    )}

                    <Button variant="secondary" onClick={() => props.onOpenPass?.()}>
                      Pass perks
                    </Button>

                    <Button variant="ghost" onClick={() => (props.onNotify ? props.onNotify() : alert("Later: enable show alerts"))}>
                      Get alerts
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Admin editor modal */}
        <Modal open={!!props.editable && editOpen} onClose={() => setEditOpen(false)} title="Edit tour dates">
          <div className="grid gap-6">
            <div className="rounded-2xl bg-white/[0.03] p-4 ring-1 ring-white/10">
              <div className="text-xs uppercase tracking-widest text-white/60">How this works</div>
              <div className="mt-2 text-sm text-white/70">
                You edit the list here. Later we’ll wire <span className="text-white/85">Save</span> to your real admin DB.
                For now it also stores a draft in your browser so you don’t lose changes.
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <label className="block">
                <span className="text-xs uppercase tracking-widest text-white/60">Headline</span>
                <input
                  value={draftConfig.headline ?? ""}
                  onChange={(e) => {
                    const next = { ...draftConfig, headline: e.target.value };
                    setDraftConfig(next);
                    persistDraft(draftShows, next);
                  }}
                  placeholder="Shows that feel like chapters."
                  className={cx(
                    "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                    "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                  )}
                />
              </label>

              <label className="block">
                <span className="text-xs uppercase tracking-widest text-white/60">Ticket portal link</span>
                <input
                  value={draftConfig.ticketPortalHref ?? ""}
                  onChange={(e) => {
                    const next = { ...draftConfig, ticketPortalHref: e.target.value };
                    setDraftConfig(next);
                    persistDraft(draftShows, next);
                  }}
                  placeholder="https://..."
                  className={cx(
                    "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                    "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                  )}
                />
              </label>

              <label className="block lg:col-span-2">
                <span className="text-xs uppercase tracking-widest text-white/60">Description</span>
                <textarea
                  value={draftConfig.description ?? ""}
                  onChange={(e) => {
                    const next = { ...draftConfig, description: e.target.value };
                    setDraftConfig(next);
                    persistDraft(draftShows, next);
                  }}
                  rows={3}
                  placeholder="Short description for the tour section..."
                  className={cx(
                    "mt-2 w-full resize-none rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                    "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                  )}
                />
              </label>
            </div>

            <div className="flex items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <Badge>Dates</Badge>
                <Badge>{draftShows.length}</Badge>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button variant="secondary" onClick={addShow}>
                  Add date
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => {
                    try {
                      localStorage.removeItem(STORAGE_KEY);
                    } catch {}
                    setDraftShows(props.shows);
                    setDraftConfig(props.config);
                  }}
                >
                  Reset draft
                </Button>
              </div>
            </div>

            <div className="grid gap-3">
              {draftShows.map((s) => (
                <div key={s.id} className="rounded-2xl bg-white/[0.03] p-4 ring-1 ring-white/10">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Pill tone="muted">Show</Pill>
                      {statusPill(s.status)}
                    </div>
                    <button
                      onClick={() => removeShow(s.id)}
                      className="rounded-full p-2 text-white/60 hover:bg-white/10 hover:text-white"
                      aria-label="Remove show"
                    >
                      <IconClose className="h-5 w-5" />
                    </button>
                  </div>

                  <div className="mt-3 grid gap-3 md:grid-cols-2">
                    <label className="block">
                      <span className="text-xs uppercase tracking-widest text-white/60">Date (ISO)</span>
                      <input
                        value={s.dateISO ?? ""}
                        onChange={(e) => updateShow(s.id, { dateISO: e.target.value })}
                        placeholder="2026-04-12"
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      />
                      <div className="mt-1 text-xs text-white/40">Use ISO when you can. It formats perfectly.</div>
                    </label>

                    <label className="block">
                      <span className="text-xs uppercase tracking-widest text-white/60">Date label (fallback)</span>
                      <input
                        value={s.dateLabel ?? ""}
                        onChange={(e) => updateShow(s.id, { dateLabel: e.target.value })}
                        placeholder="APR 12"
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      />
                    </label>

                    <label className="block">
                      <span className="text-xs uppercase tracking-widest text-white/60">City</span>
                      <input
                        value={s.city}
                        onChange={(e) => updateShow(s.id, { city: e.target.value })}
                        placeholder="Lagos"
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      />
                    </label>

                    <label className="block">
                      <span className="text-xs uppercase tracking-widest text-white/60">Venue</span>
                      <input
                        value={s.venue}
                        onChange={(e) => updateShow(s.id, { venue: e.target.value })}
                        placeholder="— Venue TBA"
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      />
                    </label>

                    <label className="block md:col-span-2">
                      <span className="text-xs uppercase tracking-widest text-white/60">Details / ticket link</span>
                      <input
                        value={s.href ?? ""}
                        onChange={(e) => updateShow(s.id, { href: e.target.value })}
                        placeholder="https://..."
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white placeholder:text-white/35",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      />
                    </label>

                    <label className="block">
                      <span className="text-xs uppercase tracking-widest text-white/60">Status</span>
                      <select
                        value={(s.status ?? "tickets") as ShowStatus}
                        onChange={(e) => updateShow(s.id, { status: e.target.value as ShowStatus })}
                        className={cx(
                          "mt-2 w-full rounded-2xl bg-white/[0.04] px-4 py-3 text-sm text-white",
                          "ring-1 ring-white/10 outline-none focus:ring-2 focus:ring-white/30"
                        )}
                      >
                        <option value="tickets" className="bg-[#0B0B10]">
                          Tickets
                        </option>
                        <option value="announce" className="bg-[#0B0B10]">
                          Announcing soon
                        </option>
                        <option value="soldout" className="bg-[#0B0B10]">
                          Sold out
                        </option>
                      </select>
                    </label>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-white/50">
                Draft is saved locally. Hook <span className="text-white/80">onSave()</span> to your admin backend later.
              </div>

              <div className="flex flex-wrap gap-2">
                <Button variant="ghost" onClick={() => setEditOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={saveNow} iconRight={saving ? <span className="text-xs">Saving…</span> : <IconArrowUpRight className="h-4 w-4" />}>
                  Save
                </Button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </section>
  );
}
