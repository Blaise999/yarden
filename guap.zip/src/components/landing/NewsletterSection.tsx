"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useReducedMotion } from "framer-motion";

// If your UI kit lives somewhere else, update this import.
import {
  Badge,
  Button,
  Card,
  MiniInput,
  MiniSelect,
  SectionHeader,
  Pill,
  cx,
  IconArrowUpRight,
  IconAnkh,
  IconPlay,
} from "@/components/landing/ui";

export type PressItem = {
  title: string;
  outlet: string;
  date: string;
  href: string;
  image: string; // local path in /public
  tag?: string;
  excerpt?: string;
};

export type EmbedVideo = {
  title: string;
  meta?: string;
  youtubeId: string; // e.g. "9lT3tKmYLO8"
  href?: string; // optional full youtube link
};

export type NewsletterPayload = {
  email: string;
  city?: string;
  interest?: string;
};

export function NewsletterSection(props: {
  pressItems?: PressItem[];
  videos?: EmbedVideo[];
  backgroundImage?: string; // local path in /public
  onSubmit?: (payload: NewsletterPayload) => Promise<void> | void;
}) {
  const reduced = useReducedMotion();
  const rootRef = useRef<HTMLElement | null>(null);

  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");
  const [interest, setInterest] = useState("Music + Visuals");

  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "err">("idle");
  const [msg, setMsg] = useState<string>("");

  const pressItems = useMemo<PressItem[]>(
    () =>
      props.pressItems ?? [
        {
          title: "Yarden talks debut EP “The One Who Descends”",
          outlet: "Wonderland Magazine",
          date: "Dec 1, 2023",
          href: "https://www.wonderlandmagazine.com/2023/12/01/yarden/",
          image: "/media/yarden/press/wonderland.jpg",
          tag: "Interview",
          excerpt: "A quick window into the EP’s mood, meaning, and process.",
        },
        {
          title: "Yarden shares debut EP “The One Who Descends”",
          outlet: "Culture Custodian",
          date: "Dec 2023",
          href: "https://culturecustodian.com/yarden-shares-debut-ep-the-one-who-descends/",
          image: "/media/yarden/press/culture-custodian.jpg",
          tag: "News",
          excerpt: "A tight write-up on the debut project and the story behind it.",
        },
        {
          title: "Best of New Music: debut EP + new single “Time”",
          outlet: "TurnTable Charts",
          date: "Dec 5, 2023",
          href: "https://www.turntablecharts.com/news/1175",
          image: "/media/yarden/press/turntable.jpg",
          tag: "Feature",
          excerpt: "A clean intro for new listeners — what to play first.",
        },
        {
          title: "Debut EP drops alongside the single “Time”",
          outlet: "Pulse Nigeria",
          date: "Dec 4, 2023",
          href: "https://www.pulse.ng/story/yarden-drops-the-one-who-descends-ep-alongside-the-new-single-time-2024072621214515034",
          image: "/media/yarden/press/pulse.jpg",
          tag: "Press",
          excerpt: "Quick coverage that’s easy to share when people ask “who’s that?”",
        },
        {
          title: "Official YouTube channel (videos + releases)",
          outlet: "YouTube",
          date: "Official",
          href: "https://www.youtube.com/@thisisyarden",
          image: "/media/yarden/press/youtube.jpg",
          tag: "Watch",
          excerpt: "All official videos in one place — clean, direct, no noise.",
        },
      ],
    [props.pressItems]
  );

  const videos = useMemo<EmbedVideo[]>(
    () =>
      props.videos ?? [
        {
          title: "Wetin (Official Video)",
          meta: "Watch on the site",
          youtubeId: "9lT3tKmYLO8",
          href: "https://www.youtube.com/watch?v=9lT3tKmYLO8",
        },
        {
          title: "Time (Visual / Film)",
          meta: "Watch on the site",
          youtubeId: "pNcM1elCxTA",
          href: "https://www.youtube.com/watch?v=pNcM1elCxTA",
        },
      ],
    [props.videos]
  );

  const bg = props.backgroundImage ?? "/media/yarden/newsletter.jpg";

  // Optional GSAP polish: press cards animate in on scroll.
  useEffect(() => {
    if (reduced) return;
    let ctx: any;

    (async () => {
      try {
        const gsapMod = await import("gsap");
        const stMod = await import("gsap/ScrollTrigger");
        const gsap = gsapMod.default;
        const ScrollTrigger = stMod.ScrollTrigger;

        gsap.registerPlugin(ScrollTrigger);

        ctx = gsap.context(() => {
          const cards = gsap.utils.toArray<HTMLElement>("[data-press-card]");
          if (!cards.length) return;

          gsap.set(cards, { y: 18, opacity: 0 });

          gsap.to(cards, {
            y: 0,
            opacity: 1,
            duration: 0.65,
            ease: "power3.out",
            stagger: 0.06,
            scrollTrigger: {
              trigger: "[data-press-grid]",
              start: "top 80%",
              end: "bottom 60%",
              toggleActions: "play none none reverse",
            },
          });
        }, rootRef);
      } catch {
        // GSAP is optional — ignore if not installed/available.
      }
    })();

    return () => {
      try {
        ctx?.revert?.();
      } catch {}
    };
  }, [reduced]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");

    const em = email.trim();
    if (!em || !em.includes("@") || em.length < 5) {
      setStatus("err");
      setMsg("Enter a real email address.");
      return;
    }

    setStatus("loading");
    try {
      await props.onSubmit?.({ email: em, city: city.trim() || undefined, interest });
      // Fallback if no handler is wired yet:
      if (!props.onSubmit) {
        await new Promise((r) => setTimeout(r, 450));
      }

      setStatus("ok");
      setMsg("You’re in. We’ll only send drops, moments, and tickets.");
      setEmail("");
      setCity("");
      setInterest("Music + Visuals");
    } catch {
      setStatus("err");
      setMsg("Couldn’t submit right now. Try again.");
    }
  }

  return (
    <section id="newsletter" ref={rootRef as any} className="relative py-20 md:py-24">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.09),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(255,255,255,0.06),transparent_60%)]" />
      </div>

      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeader
          eyebrow="Sign up"
          title="Get the next drop first."
          desc="Links, visuals, and show notes — sent when it matters. No noise."
          right={
            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                href="https://www.youtube.com/@thisisyarden"
                target="_blank"
                iconRight={<IconArrowUpRight className="h-4 w-4" />}
              >
                YouTube
              </Button>
              <Button
                variant="ghost"
                href="https://open.spotify.com/artist/1nN9bKS2bD4OHNrKkS0Djd"
                target="_blank"
                iconRight={<IconArrowUpRight className="h-4 w-4" />}
              >
                Spotify
              </Button>
            </div>
          }
        />

        {/* Press + Watch */}
        <div className="grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
          <Card className="overflow-hidden">
            <div className="p-6 md:p-8">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-white/70">
                  <IconAnkh className="h-5 w-5" />
                  <div className="text-xs uppercase tracking-widest">Press & News</div>
                </div>
                <Pill tone="muted">Admin can update anytime</Pill>
              </div>

              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/60">
                These cards are “living content.” Today they’re curated links. Later, you’ll pull them from your admin panel / CMS.
              </p>

              <div data-press-grid className="mt-6 grid gap-4 sm:grid-cols-2">
                {pressItems.map((p) => (
                  <Link
                    key={p.href}
                    href={p.href}
                    target="_blank"
                    rel="noreferrer"
                    data-press-card
                    className={cx(
                      "group overflow-hidden rounded-3xl bg-white/[0.03] ring-1 ring-white/10",
                      "hover:bg-white/[0.05] transition"
                    )}
                    aria-label={`Open: ${p.title}`}
                  >
                    <div className="relative aspect-[16/10]">
                      <Image
                        src={p.image}
                        alt={`${p.outlet} cover`}
                        fill
                        sizes="(max-width: 1024px) 100vw, 50vw"
                        className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />
                      <div className="absolute left-4 top-4 flex flex-wrap gap-2">
                        {p.tag ? <Pill tone="brand">{p.tag}</Pill> : null}
                        <Pill tone="muted">{p.outlet}</Pill>
                      </div>
                      <div className="absolute bottom-3 left-4 right-4">
                        <div className="text-xs uppercase tracking-[0.28em] text-white/60">{p.date}</div>
                        <div className="mt-1 text-base font-semibold text-white">{p.title}</div>
                      </div>
                    </div>

                    <div className="p-5">
                      {p.excerpt ? <div className="text-sm text-white/60">{p.excerpt}</div> : null}
                      <div className="mt-3 flex items-center gap-2 text-sm text-white/60">
                        <span>Read</span>
                        <IconArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-2">
                <Badge>Curated</Badge>
                <Badge>Easy to share</Badge>
                <Badge>Replace thumbnails in /public</Badge>
              </div>
            </div>
          </Card>

          <Card className="overflow-hidden">
            <div className="p-6 md:p-8">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-white/70">
                  <IconPlay className="h-5 w-5" />
                  <div className="text-xs uppercase tracking-widest">Watch here</div>
                </div>
                <Button
                  variant="ghost"
                  href="https://www.youtube.com/@thisisyarden"
                  target="_blank"
                  className="px-4 py-2"
                  iconRight={<IconArrowUpRight className="h-4 w-4" />}
                >
                  Channel
                </Button>
              </div>

              <div className="mt-6 grid gap-4">
                {videos.slice(0, 2).map((v) => (
                  <div key={v.youtubeId} className="overflow-hidden rounded-3xl bg-white/[0.03] ring-1 ring-white/10">
                    <div className="relative aspect-video">
                      <iframe
                        className="absolute inset-0 h-full w-full"
                        src={`https://www.youtube.com/embed/${v.youtubeId}?rel=0&modestbranding=1`}
                        title={v.title}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-xs uppercase tracking-widest text-white/60">{v.meta ?? "Video"}</div>
                      <div className="mt-2 text-base font-semibold text-white">{v.title}</div>
                      {v.href ? (
                        <div className="mt-3">
                          <Button
                            variant="secondary"
                            href={v.href}
                            target="_blank"
                            className="px-4 py-2"
                            iconRight={<IconArrowUpRight className="h-4 w-4" />}
                          >
                            Open on YouTube
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 rounded-3xl bg-white/[0.03] p-6 ring-1 ring-white/10">
                <div className="flex items-center gap-2 text-white/70">
                  <IconAnkh className="h-4 w-4" />
                  <div className="text-xs uppercase tracking-widest">Why this matters</div>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-white/60">
                  People don’t leave a page to “go find you.” If the video is right here, they stay longer — and they actually tap follow.
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Signup Card (same layout vibe as your original) */}
        <div className="mt-8">
          <Card className="overflow-hidden">
            <div className="grid lg:grid-cols-[1.1fr_.9fr]">
              <div className="p-7 md:p-10">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge>Early links</Badge>
                  <Badge>Show alerts</Badge>
                  <Badge>Merch drops</Badge>
                </div>

                <form className="mt-8 grid gap-4" onSubmit={submit}>
                  <MiniInput label="Email" placeholder="you@example.com" value={email} onChange={setEmail} type="email" />

                  <div className="grid gap-4 md:grid-cols-2">
                    <MiniInput label="City" placeholder="Lagos" value={city} onChange={setCity} />
                    <MiniSelect
                      label="Interest"
                      value={interest}
                      onChange={setInterest}
                      options={[
                        { label: "Music + Visuals", value: "Music + Visuals" },
                        { label: "Tour alerts", value: "Tour alerts" },
                        { label: "Merch drops", value: "Merch drops" },
                        { label: "All updates", value: "All updates" },
                      ]}
                    />
                  </div>

                  <div className="mt-2 flex flex-wrap items-center gap-3">
                    <Button variant="primary" type="submit">
                      {status === "loading" ? "Joining..." : "Join list"}
                    </Button>

                    <span className="text-xs text-white/50">No spam. Only drops, moments, and tickets.</span>
                  </div>

                  {msg ? (
                    <div
                      className={cx(
                        "mt-2 rounded-2xl p-4 ring-1",
                        status === "ok" && "bg-emerald-500/10 ring-emerald-300/20 text-emerald-50",
                        status === "err" && "bg-rose-500/10 ring-rose-300/20 text-rose-50",
                        status !== "ok" && status !== "err" && "bg-white/[0.04] ring-white/10 text-white/80"
                      )}
                    >
                      <div className="text-sm">{msg}</div>
                    </div>
                  ) : null}
                </form>
              </div>

              <div className="relative min-h-[320px]">
                <Image
                  src={bg}
                  alt="Newsletter background"
                  fill
                  sizes="(max-width: 1024px) 100vw, 40vw"
                  className="object-cover"
                  priority={false}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="rounded-3xl bg-black/45 p-6 ring-1 ring-white/10 backdrop-blur-xl">
                    <div className="text-xs uppercase tracking-[0.28em] text-white/60">Next drop</div>
                    <div className="mt-2 text-lg font-semibold">Make the rollout feel intentional.</div>
                    <p className="mt-2 text-sm text-white/60">
                      Tease → reveal → release → visual → live moment → community unlock.
                    </p>

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button
                        variant="secondary"
                        href="https://www.instagram.com/thisisyarden/"
                        target="_blank"
                        iconRight={<IconArrowUpRight className="h-4 w-4" />}
                      >
                        Instagram
                      </Button>
                      <Button
                        variant="ghost"
                        href="https://x.com/thisisyarden"
                        target="_blank"
                        iconRight={<IconArrowUpRight className="h-4 w-4" />}
                      >
                        X (Twitter)
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <div className="mt-4 text-xs text-white/45">
            Admin note: replace press thumbnails in{" "}
            <span className="text-white/65">/public/media/yarden/press/</span> (e.g. wonderland.jpg, pulse.jpg).
          </div>
        </div>
      </div>
    </section>
  );
}
