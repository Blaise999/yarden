"use client";

import React, { useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";

import {
  Badge,
  Button,
  Card,
  cx,
  IconAnkh,
  IconArrowUpRight,
  Pill,
  SectionHeader,
} from "@/components/landing/ui";

export type MerchLink = { label: string; href: string };

export type MerchItem = {
  name: string;
  price?: string; // e.g. "₦15,000" or "£25"
  image: string; // placeholder file path like "/media/yarden/merch-tee.jpg"
  tag?: string; // "Drop soon" / "Limited" / "New"
  href?: string; // primary link (optional)
  links?: MerchLink[]; // optional multi-platform links
  available?: boolean; // if false -> shows "Coming soon"
};

type Props = {
  merch?: MerchItem[];
  storeHref?: string; // future: shop home
  adminHref?: string; // future: admin merch page
  showAdminHint?: boolean; // show/hide admin card
  initialCount?: number; // how many items before "See more"
};

const FALLBACK: MerchItem[] = [
  {
    name: "Ankh Tee (Black)",
    price: "₦ —",
    image: "/media/yarden/merch-tee.jpg",
    tag: "Drop soon",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
  {
    name: "Era Poster (A2)",
    price: "₦ —",
    image: "/media/yarden/merch-poster.jpg",
    tag: "Limited",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
  {
    name: "Ankh Cap",
    price: "₦ —",
    image: "/media/yarden/merch-cap.jpg",
    tag: "New",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
  {
    name: "Pass Holder Lanyard",
    price: "₦ —",
    image: "/media/yarden/merch-lanyard.jpg",
    tag: "Exclusive",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
  {
    name: "Muse Sticker Pack",
    price: "₦ —",
    image: "/media/yarden/merch-stickers.jpg",
    tag: "Soon",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
  {
    name: "Ankh Hoodie",
    price: "₦ —",
    image: "/media/yarden/merch-hoodie.jpg",
    tag: "Soon",
    available: false,
    links: [{ label: "Notify me", href: "#" }],
  },
];

function MerchCard({ item }: { item: MerchItem }) {
  const primaryHref = item.href || item.links?.[0]?.href || "#";
  const primaryLabel = item.links?.[0]?.label || (item.available === false ? "Notify me" : "View");

  return (
    <Card className="group overflow-hidden bg-white/[0.03]">
      <div className="relative aspect-[4/5]">
        <Image
          src={item.image}
          alt={item.name}
          fill
          sizes="(max-width: 1024px) 50vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />

        {/* top-left tag */}
        <div className="absolute left-4 top-4 flex items-center gap-2">
          {item.tag ? <Pill tone="brand">{item.tag}</Pill> : null}
          {item.available === false ? <Pill tone="muted">Coming soon</Pill> : null}
        </div>

        {/* bottom hint */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="rounded-2xl bg-black/40 p-4 ring-1 ring-white/10 backdrop-blur-xl">
            <div className="text-sm font-semibold text-white">{item.name}</div>
            <div className="mt-1 flex items-center justify-between gap-3">
              <div className="text-sm text-white/60">{item.price || "—"}</div>
              <Link
                href={primaryHref}
                target={primaryHref.startsWith("http") ? "_blank" : undefined}
                rel={primaryHref.startsWith("http") ? "noreferrer" : undefined}
                className="inline-flex items-center gap-2 text-sm font-medium text-white/80 hover:text-white"
              >
                <span>{primaryLabel}</span>
                <IconArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* optional multi-links */}
      {item.links?.length ? (
        <div className="p-5">
          <div className="flex flex-wrap gap-2">
            {item.links.slice(0, 3).map((l) => (
              <Link
                key={l.label}
                href={l.href}
                target={l.href.startsWith("http") ? "_blank" : undefined}
                rel={l.href.startsWith("http") ? "noreferrer" : undefined}
                className={cx(
                  "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium",
                  "bg-white/5 text-white/75 ring-1 ring-white/10 hover:bg-white/8 hover:text-white"
                )}
              >
                <span>{l.label}</span>
                <IconArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            ))}
            {item.links.length > 3 ? <Badge>+{item.links.length - 3} more</Badge> : null}
          </div>
        </div>
      ) : null}
    </Card>
  );
}

function AdminShelf({ adminHref }: { adminHref?: string }) {
  return (
    <Card className="relative overflow-hidden p-6">
      <div className="absolute inset-0 opacity-[0.16]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,0.20),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_70%,rgba(255,255,255,0.10),transparent_55%)]" />
      </div>

      <div className="relative">
        <div className="flex items-center gap-2 text-white/70">
          <IconAnkh className="h-5 w-5" />
          <div className="text-xs uppercase tracking-widest">Admin slot</div>
        </div>

        <div className="mt-4 text-lg font-semibold text-white">Merch updates live here.</div>
        <p className="mt-2 text-sm leading-relaxed text-white/60">
          When you’re ready, wire this section to a store (Shopify/Selar) or your own admin panel.
          The UI is already built to support multiple platform links per item.
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {adminHref ? (
            <Button variant="primary" href={adminHref} iconRight={<IconArrowUpRight className="h-4 w-4" />}>
              Open merch admin
            </Button>
          ) : (
            <Button
              variant="secondary"
              onClick={() => alert("Admin panel not connected yet. Later: /admin/merch")}
            >
              Admin panel (later)
            </Button>
          )}
          <Pill tone="muted">Tip: keep images 4:5</Pill>
        </div>

        <div className="mt-6 rounded-2xl bg-white/[0.03] p-4 ring-1 ring-white/10">
          <div className="text-xs uppercase tracking-widest text-white/60">How it will work</div>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li className="flex gap-3">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-white/50" />
              Admin adds merch (name, price, image, links)
            </li>
            <li className="flex gap-3">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-white/50" />
              Site updates instantly (no redesign)
            </li>
            <li className="flex gap-3">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-white/50" />
              “Coming soon” stays clean until launch
            </li>
          </ul>
        </div>
      </div>
    </Card>
  );
}

export default function StoreSection({
  merch,
  storeHref = "#",
  adminHref,
  showAdminHint = true,
  initialCount = 4,
}: Props) {
  const reduced = useReducedMotion();
  const items = useMemo(() => (merch?.length ? merch : FALLBACK), [merch]);
  const [expanded, setExpanded] = useState(false);

  const shown = expanded ? items : items.slice(0, initialCount);
  const canExpand = items.length > initialCount;

  return (
    <section id="store" className="relative py-20 md:py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <SectionHeader
          eyebrow="Store"
          title="Merch that matches the era."
          desc="Placeholders for now — but built like a real artist store. When merch is ready, admin can drop items in and the section stays clean."
          right={
            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                href={storeHref}
                iconRight={<IconArrowUpRight className="h-4 w-4" />}
              >
                Open store
              </Button>
              {canExpand ? (
                <Button variant="ghost" onClick={() => setExpanded((v) => !v)}>
                  {expanded ? "See less" : "See more"}
                </Button>
              ) : null}
            </div>
          }
        />

        <motion.div
          initial={reduced ? undefined : { opacity: 0, y: 12 }}
          whileInView={reduced ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-4"
        >
          {shown.map((m) => (
            <MerchCard key={m.name} item={m} />
          ))}
        </motion.div>

        {canExpand ? (
          <div className="mt-8 flex items-center justify-center">
            <Button variant="secondary" onClick={() => setExpanded((v) => !v)}>
              {expanded ? "Show fewer items" : "See more merch"}
            </Button>
          </div>
        ) : null}

        {showAdminHint ? (
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            <AdminShelf adminHref={adminHref} />
            <Card className="p-6">
              <div className="text-xs uppercase tracking-widest text-white/60">Drop rules</div>
              <div className="mt-3 text-lg font-semibold text-white">Keep it tight.</div>
              <p className="mt-2 text-sm text-white/60">
                4–8 products max per era. Quality photos, one clean background style, and consistent pricing format.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge>4:5 images</Badge>
                <Badge>Short names</Badge>
                <Badge>Clear links</Badge>
              </div>
            </Card>
            <Card className="p-6">
              <div className="text-xs uppercase tracking-widest text-white/60">Checkout later</div>
              <div className="mt-3 text-lg font-semibold text-white">No pressure.</div>
              <p className="mt-2 text-sm text-white/60">
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Pill tone="muted">Selar</Pill>
                <Pill tone="muted">Paystack</Pill>
                <Pill tone="muted">Shopify</Pill>
              </div>
            </Card>
          </div>
        ) : null}
      </div>
    </section>
  );
}
